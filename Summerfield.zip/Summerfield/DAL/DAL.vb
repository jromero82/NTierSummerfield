﻿Option Strict On
Imports SDC = System.Data.Common
Imports Summerfield.Data.Conn
Imports Summerfield.Utilities

Namespace Summerfield.Data
    Public NotInheritable Class DAL
        Inherits DALConn

        Private Sub New()
        End Sub

#Region "DataAccess"

        Public Shared Function GetDataReader(ByVal sproc As String, Optional parms As List(Of Parm) = Nothing) As SDC.DbDataReader

            Dim cmd As SDC.DbCommand = LoadParms(sproc, parms)
            cmd.Connection.Open()
            Dim dr As SDC.DbDataReader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            Return dr

        End Function

        Public Shared Function GetDataTable(ByVal sproc As String, Optional parms As List(Of Parm) = Nothing) As DataTable

            Dim cmd As SDC.DbCommand = LoadParms(sproc, parms)

            Dim factory As SDC.DbProviderFactory = SDC.DbProviderFactories.GetFactory(My.Settings.provider)
            Dim da As SDC.DbDataAdapter = factory.CreateDataAdapter
            da.SelectCommand = cmd
            da.SelectCommand.Connection = cmd.Connection
            Dim dt As New DataTable
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey
            da.Fill(dt)
            Return dt

        End Function

        Public Shared Function GetDataSet(ByVal sproc As String, Optional parms As List(Of Parm) = Nothing) As DataSet

            Dim cmd As SDC.DbCommand = LoadParms(sproc, parms)

            Dim da As SDC.DbDataAdapter = Nothing
            da.SelectCommand = cmd
            da.SelectCommand.Connection = cmd.Connection
            Dim ds As New DataSet
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey
            da.Fill(ds)
            Return ds

        End Function

        Public Shared Function GetDataRow(ByVal sproc As String, Optional parms As List(Of Parm) = Nothing) As DataRow

            Dim cmd As SDC.DbCommand = LoadParms(sproc, parms)

            Dim da As SDC.DbDataAdapter = Nothing
            da.SelectCommand = cmd
            da.SelectCommand.Connection = cmd.Connection
            Dim dt As New DataTable
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey
            da.Fill(dt)
            Return dt.Rows(0)

        End Function

        Public Shared Function GetScalar(ByVal sproc As String, Optional parms As List(Of Parm) = Nothing) As Object

            Dim cmd As SDC.DbCommand = LoadParms(sproc, parms)

            Using cmd.Connection
                cmd.Connection.Open()
                Return cmd.ExecuteScalar
            End Using

        End Function

        Public Shared Function UpdateData(ByVal sproc As String, Optional ByVal parms As List(Of Parm) = Nothing) As Boolean

            Dim cmd As SDC.DbCommand = LoadParms(sproc, parms)

            Using cmd.Connection
                cmd.Connection.Open()
                cmd.ExecuteNonQuery()
                For i As Integer = 0 To parms.Count - 1
                    Dim parameter As Parm = parms(i)
                    parameter.parmValue = cmd.Parameters(i).Value
                    parms(i) = parameter
                Next

                Return True
            End Using

        End Function

#End Region

        Private Shared Function LoadParms(ByVal sproc As String, ByVal parms As List(Of Parm)) As SDC.DbCommand

            Dim factory As SDC.DbProviderFactory = SDC.DbProviderFactories.GetFactory(My.Settings.provider)
            Dim cmd As SDC.DbCommand = factory.CreateCommand
            cmd.Connection = getConnection(factory)
            cmd.CommandText = sproc
            cmd.CommandType = CommandType.StoredProcedure

            If Not parms Is Nothing Then
                For Each Parm In parms
                    Dim x As SDC.DbParameter = cmd.CreateParameter
                    x.ParameterName = Parm.parmName
                    x.Size = Parm.ParmSize
                    x.Value = Parm.parmValue
                    x.DbType = Parm.ParmDataType
                    x.Direction = Parm.ParmDirection
                    cmd.Parameters.Add(x)
                Next
            End If

            Return cmd

        End Function

    End Class
End Namespace

Namespace Summerfield.Data.Conn
    Public MustInherit Class DALConn

        Protected Shared Function getConnection(ByVal factory As SDC.DbProviderFactory) As SDC.DbConnection
            Dim cnn As SDC.DbConnection = factory.CreateConnection()
            cnn.ConnectionString = (My.Settings.cnnString)
            Return cnn
        End Function

    End Class
End Namespace
