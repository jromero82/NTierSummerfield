﻿Option Strict On
Imports Summerfield.SQLBuilder
Namespace Summerfield.BOL

    Public Class TopicReport

        Private mFullName As String
        Private mTopic As String

#Region "Properties"

        ''' <summary>
        ''' Gets or sets the full name.
        ''' </summary>
        ''' <value>
        ''' The full name.
        ''' </value>
        Public Property FullName As String
            Get
                Return mFullName
            End Get
            Set(value As String)
                mFullName = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the topic.
        ''' </summary>
        ''' <value>
        ''' The topic.
        ''' </value>
        Public Property Topic As String
            Get
                Return mTopic
            End Get
            Set(value As String)
                mTopic = value
            End Set
        End Property

#End Region

        ''' <summary>
        ''' Gets the volunteer topics.
        ''' </summary><returns></returns>
        Public Shared Function getVolunteerTopics() As List(Of TopicReport)
            Dim dt As DataTable = TopicSQL.getVolunteerTopics()
            Return Repackager(dt)
        End Function

        ''' <summary>
        ''' Repackagers the specified datatable.
        ''' </summary>
        ''' <param name="DT">The datatable.</param><returns></returns>
        Friend Shared Function Repackager(ByVal DT As DataTable) As List(Of TopicReport)
            Dim newVolunteerList As New List(Of TopicReport)
            For i As Int32 = 0 To DT.Rows.Count - 1
                Dim newVol As TopicReport = New TopicReport
                newVol.FullName = CStr(DT.Rows(i).Item("FullName"))
                newVol.Topic = CStr(DT.Rows(i).Item("TopicName"))
                newVolunteerList.Add(newVol)
            Next
            Return newVolunteerList

        End Function

    End Class

End Namespace
