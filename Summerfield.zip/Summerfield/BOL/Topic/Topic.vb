﻿Option Strict On

Imports Summerfield.SQLBuilder
Imports Summerfield.Utilities

Namespace Summerfield.BOL

    ''' <summary>
    ''' Class for the Topic
    ''' </summary>
    Public Class Topic
        Implements ITopic

        Private mTopicID As Integer
        Private mTopicName As String


#Region "Properties"

        ''' <summary>
        ''' Gets or sets the topic ID.
        ''' </summary>
        ''' <value>
        ''' The topic ID.
        ''' </value>
        Public Property TopicID As Integer Implements ITopic.TopicID
            Get
                Return mTopicID
            End Get
            Set(value As Integer)
                mTopicID = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the name of the topic.
        ''' </summary>
        ''' <value>
        ''' The name of the topic.
        ''' </value>
        Public Property TopicName As String Implements ITopic.TopicName
            Get
                Return mTopicName
            End Get
            Set(value As String)
                mTopicName = value
            End Set
        End Property



#End Region

#Region "Topic Factory"

        ''' <summary>
        ''' Addtopics the specified topic name.
        ''' </summary>
        ''' <param name="TopicName">Name of the topic.</param><returns></returns>
        Public Shared Function Addtopic(TopicName As String) As Boolean
            Return TopicSQL.addTopic(TopicName)
        End Function

        ''' <summary>
        ''' Deletes the specified topic id.
        ''' </summary>
        ''' <param name="topicId">The topic id.</param><returns></returns>
        Public Shared Function delete(topicId As Integer) As Boolean
            Return TopicSQL.DeleteTopic(topicId)
        End Function

        ''' <summary>
        ''' Creates this instance.
        ''' </summary><returns></returns>
        Public Shared Function Create() As Topic
            Return New Topic
        End Function

        ''' <summary>
        ''' Creates the specified topic ID.
        ''' </summary>
        ''' <param name="TopicID">The topic ID.</param><returns></returns>
        Public Shared Function Create(ByVal TopicID As Integer) As Topic
            If String.IsNullOrEmpty(CStr(TopicID)) Then
                Throw New ArgumentException("Topic id is invalid")
            End If

            Dim DT As DataTable = TopicSQL.RetrieveTopic(TopicID)
            If DT.Rows.Count > 0 Then
                Dim TopicList As List(Of Topic) = ConvertDT(DT)
                Dim vol As Topic = TopicList(0)
                Return vol
            Else
                Throw New DataException("Topic not found")
            End If
        End Function

        ''' <summary>
        ''' Gets the volunteer topic.
        ''' </summary>
        ''' <param name="volunteerID">The volunteer ID.</param><returns></returns>
        Public Shared Function getVolunteerTopic(volunteerID As Integer) As List(Of Topic)
            Dim dt As DataTable = TopicSQL.getVolunteerTopic(volunteerID)
            Return ConvertDT(dt)
        End Function

        ''' <summary>
        ''' Gets the topics.
        ''' </summary><returns></returns>
        Public Shared Function TopicLookup() As List(Of Topic)
            Dim dt As DataTable = TopicSQL.RetrieveTopic()
            Return ConvertDT(dt)
        End Function

        ''' <summary>
        ''' Converts the datatable to List of Topic.
        ''' </summary>
        ''' <param name="DT">The DT.</param><returns></returns>
        Friend Shared Function ConvertDT(ByVal DT As DataTable) As List(Of Topic)

            Dim newTopicList As New List(Of Topic)
            For i As Int32 = 0 To DT.Rows.Count - 1
                Dim newTopic As Topic = New Topic
                newTopic.TopicID = CInt((DT.Rows(i).Item("topicID")))
                newTopic.TopicName = CStr(DT.Rows(i).Item("topicName"))

                newTopicList.Add(newTopic)
            Next
            Return newTopicList

        End Function

#End Region

    End Class

End Namespace