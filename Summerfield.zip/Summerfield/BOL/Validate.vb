﻿Option Strict On
Imports System.Text.RegularExpressions
Imports Summerfield.Utilities

Namespace Summerfield.BOL

    Public Class Validate

        ''' <summary>
        ''' Determines whether [is valid email] [the specified email].
        ''' </summary>
        ''' <param name="email">The email.</param><returns>
        '''   <c>true</c> if [is valid email] [the specified email]; otherwise, <c>false</c>.
        ''' </returns>
        Public Shared Function isValidEmail(email As String) As Boolean

            Dim regEx As New Regex("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$")
            If regEx.IsMatch(email) Then
                Return True
            End If

            Return False

        End Function

        ''' <summary>
        ''' Validates the length of the field.
        ''' </summary>
        ''' <param name="value">The value.</param>
        ''' <param name="size">The size.</param>
        ''' <param name="propertyname">The propertyname.</param>
        ''' <param name="sizechoice">The sizechoice.</param><returns></returns>
        Public Shared Function ValidateFieldLength(ByVal value As String, ByVal size As Long, ByVal propertyname As String, ByVal sizechoice As SizeOperator) As Boolean
            Dim strErr As String
            If sizechoice = SizeOperator.CanBeLessThan Then 'can be less than defined size
                If value.Length > size Then
                    strErr = "The " & propertyname & " cannot be greater than " & size & " characters in length."
                    Throw New DataException(strErr)
                End If
            Else
                If value.Length <> size Then 'must be equal to defined size
                    strErr = "The " & propertyname & " must be  " & size & " characters in length."
                    Throw New DataException(strErr)
                End If
            End If
            Return True
        End Function

        ''' <summary>
        ''' Validates the string value.
        ''' </summary>
        ''' <param name="value">The value.</param>
        ''' <param name="state">The state.</param>
        ''' <param name="propertyname">The propertyname.</param><returns></returns>
        Public Shared Function ValidateStringValue(ByVal value As String, ByVal state As CheckStringValue, ByVal propertyname As String) As Boolean
            Dim strErr As String
            If state = CheckStringValue.MustBeNumeric Then
                If Decimal.TryParse(value, New Decimal) = False Then
                    strErr = "The " & propertyname & " must be numeric."
                    Throw New DataException(strErr)
                End If
            Else
                If String.IsNullOrEmpty(value) Then
                    strErr = "The " & propertyname & " cannot be null or empty."
                    Throw New DataException(strErr)
                End If
            End If
            Return True
        End Function

        ''' <summary>
        ''' Validates the numeric value.
        ''' </summary>
        ''' <param name="value">The value.</param>
        ''' <param name="state">The state.</param>
        ''' <param name="propertyname">The propertyname.</param><returns></returns>
        Public Shared Function ValidateNumericValue(ByVal value As Decimal, ByVal state As CheckNumericValue, ByVal propertyname As String) As Boolean
            Dim strErr As String
            If state = CheckNumericValue.MustNotBeNegative Then
                If value < 0 Then
                    strErr = "The " & propertyname & " must not be negative."
                    Throw New DataException(strErr)
                End If
            Else
                If value = 0 Then
                    strErr = "The " & propertyname & " must not be 0.'"
                    Throw New DataException(strErr)
                End If
            End If
            Return True
        End Function

    End Class

End Namespace
