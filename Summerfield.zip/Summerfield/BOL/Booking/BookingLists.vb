﻿Option Strict On
Imports Summerfield.Utilities
Imports Summerfield.SQLBuilder

Namespace Summerfield.BOL

    ''' <summary>
    ''' Class for the lists of bookings
    ''' </summary>
    Public Class BookingLists

        Private mVolunteerID As Integer
        Private mBookingID As Integer
        Private mVolunteerName As String

        Private mTeacherName As String
        Private mStatus As String
        Private mCreationDate As Date
        Private mBookingDate As Date
        Private mTopicName As String
        Private mTopicID As Integer

#Region "Properties"

        ''' <summary>
        ''' Gets or sets the volunteer ID.
        ''' </summary>
        ''' <value>
        ''' The volunteer ID.
        ''' </value>
        Public Property VolunteerID As Integer
            Get
                Return mVolunteerID
            End Get
            Set(value As Integer)
                mVolunteerID = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the topic ID.
        ''' </summary>
        ''' <value>
        ''' The topic ID.
        ''' </value>
        Public Property TopicID As Integer
            Get
                Return mTopicID
            End Get
            Set(value As Integer)
                mTopicID = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the booking ID.
        ''' </summary>
        ''' <value>
        ''' The booking ID.
        ''' </value>
        Public Property BookingID As Integer
            Get
                Return mBookingID
            End Get
            Set(value As Integer)
                mBookingID = value
            End Set

        End Property
        ''' <summary>
        ''' Gets or sets the name of the volunteer.
        ''' </summary>
        ''' <value>
        ''' The name of the volunteer.
        ''' </value>
        Public Property VolunteerName As String
            Get
                Return mVolunteerName
            End Get
            Set(value As String)
                mVolunteerName = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the name of the teacher.
        ''' </summary>
        ''' <value>
        ''' The name of the teacher.
        ''' </value>
        Public Property TeacherName As String
            Get
                Return mTeacherName
            End Get
            Set(value As String)
                mTeacherName = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the status.
        ''' </summary>
        ''' <value>
        ''' The status.
        ''' </value>
        Public Property Status As String
            Get
                Return mStatus
            End Get
            Set(value As String)
                mStatus = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the creation date.
        ''' </summary>
        ''' <value>
        ''' The creation date.
        ''' </value>
        Public Property CreationDate As Date
            Get
                Return mCreationDate
            End Get
            Set(value As Date)
                mCreationDate = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the booking date.
        ''' </summary>
        ''' <value>
        ''' The booking date.
        ''' </value>
        Public Property BookingDate As Date
            Get
                Return mBookingDate
            End Get
            Set(value As Date)
                mBookingDate = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the topic.
        ''' </summary>
        ''' <value>
        ''' The topic.
        ''' </value>
        Public Property Topic As String
            Get
                Return mTopicName
            End Get
            Set(value As String)
                mTopicName = value
            End Set
        End Property

#End Region

        ''' <summary>
        ''' Searches the bookings by date.
        ''' </summary>
        ''' <param name="mindate">The mindate.</param>
        ''' <param name="maxdate">The maxdate.</param><returns></returns>
        Public Shared Function searchBookingsByDate(mindate As Date, maxdate As Date) As List(Of BookingLists)
            Dim dt As DataTable = BookingSQL.getBookingByDate(mindate, maxdate)
            Dim xBook As List(Of BookingLists) = Repackager(dt)
            Return xBook
        End Function

        ''' <summary>
        ''' Searches the bookings by volunteer.
        ''' </summary>
        ''' <param name="volunteerName">Name of the volunteer.</param><returns></returns>
        Public Shared Function searchBookingsByVolunteer(volunteerName As String) As List(Of BookingLists)
            Dim dt As DataTable = BookingSQL.getBookingByVolunteer(volunteerName)
            Dim xBook As List(Of BookingLists) = Repackager(dt)
            Return xBook
        End Function

        ''' <summary>
        ''' Searches the bookings by teacher.
        ''' </summary>
        ''' <param name="teachername">The teacher name.</param><returns></returns>
        Public Shared Function searchBookingsByTeacher(teachername As String) As List(Of BookingLists)
            Dim dt As DataTable = BookingSQL.getBookingByTeacher(teachername)
            Dim xBook As List(Of BookingLists) = Repackager(dt)
            Return xBook
        End Function


        ''' <summary>
        ''' Gets the volunteer bookings.
        ''' </summary>
        ''' <param name="volID">The volunteer ID.</param><returns></returns>
        Public Shared Function getVolunteerBookings(volID As Integer) As List(Of BookingLists)
            Dim dt As DataTable = BookingSQL.Retrieve(volID)
            Dim xBook As List(Of BookingLists) = Repackager(dt)
            Return xBook
        End Function

        ''' <summary>
        ''' Gets the teacher bookings.
        ''' </summary>
        ''' <param name="teachID">The teacher ID.</param><returns></returns>
        Public Shared Function getTeacherBookings(teachID As Integer) As List(Of BookingLists)
            Dim dt As DataTable = BookingSQL.getTeacherBookings(teachID)
            Dim xBook As List(Of BookingLists)
        End Function


        ''' <summary>
        ''' Repackages the specified table.
        ''' </summary>
        ''' <param name="table">The table.</param>
        ''' <param name="type">The type.</param><returns></returns>
        Private Shared Function Repackager(table As DataTable, Optional type As RetrieveType = RetrieveType.EntireFile) As List(Of BookingLists)
            Dim booking As BookingLists = Nothing
            Dim lst As New List(Of BookingLists)

            For i = 0 To table.Rows.Count - 1
                Dim xVolBook As BookingLists = New BookingLists()
                'xVolBook.blnTrustedSource = True
                'xVolBook.VolunteerID = CInt(table.Rows(i).Item("volunteerID"))
                xVolBook.BookingID = CInt(table.Rows(i).Item("bookingID"))
                xVolBook.VolunteerID = CInt(table.Rows(i).Item("volunteerID"))
                xVolBook.VolunteerName = CStr(table.Rows(i).Item("VolunteerName"))
                xVolBook.TeacherName = CStr(table.Rows(i).Item("TeacherName"))
                xVolBook.Status = CStr(table.Rows(i).Item("status"))
                xVolBook.CreationDate = CDate(table.Rows(i).Item("creationDate"))
                xVolBook.BookingDate = CDate(table.Rows(i).Item("bookingDate"))
                xVolBook.Topic = CStr(table.Rows(i).Item("topicName"))
                xVolBook.TopicID = CInt(table.Rows(i).Item("Topic"))

                lst.Add(xVolBook)
            Next

            'booking.blnTrustedSource = False
            Return lst

        End Function
    End Class

    
End Namespace
