﻿Option Strict On
Imports Summerfield.SQLBuilder
Imports Summerfield.Utilities

Namespace Summerfield.BOL

    ''' <summary>
    ''' Create, Update, ande Delete Methods
    ''' </summary>
    Public Class BookingCUD

#Region "Insert, Update, and Delete Methods"

        ''' <summary>
        ''' Inserts the specified booking.
        ''' </summary>
        ''' <param name="booking">The booking.</param><returns></returns>
        Public Shared Function Insert(booking As Booking) As Boolean
            If booking.isComplete = False Then
                Throw New ArgumentException("Booking not valid")
            End If
            Return BookingSQL.Create(DirectCast(booking, IBooking))
        End Function

        ''' <summary>
        ''' Updates the specified teacher.
        ''' </summary>
        ''' <param name="teacher">The teacher.</param><returns></returns>
        Public Shared Function Update(teacher As Teacher) As Boolean
            If teacher.isComplete = False Then
                Throw New ArgumentException("Teacher not valid")
            End If
            Return TeacherSQL.Modify(DirectCast(teacher, ITeacher))
        End Function

        ''' <summary>
        ''' Creates the specified booking.
        ''' </summary>
        ''' <param name="xBook">The booking.</param><returns></returns>
        Public Shared Function create(xBook As Booking) As Boolean
            Return BookingSQL.Create(xBook)
        End Function

#End Region

    End Class


End Namespace

