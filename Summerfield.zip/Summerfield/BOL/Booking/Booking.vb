﻿Option Strict On
Imports Summerfield.Utilities
Imports Summerfield.SQLBuilder

Namespace Summerfield.BOL


    ''' <summary>
    ''' Class for the volunteer bookings
    ''' </summary>
    Public Class Booking
        Implements IBooking

        Private mBookingID As Integer
        Private mBookingDate As Date
        Private mCreationDate As Date
        Private mStatus As String
        Private mTeacherID As Integer
        Private mvolunteerID As Integer
        Private mTopicName As String
        Private mTopicID As Integer


#Region "Factory"

#Region "Properties"

        Dim blnTrustedSource As Boolean


        ''' <summary>
        ''' Gets or sets the booking ID.
        ''' </summary>
        ''' <value>
        ''' The booking ID.
        ''' </value>
        Public Property BookingID As Integer Implements Utilities.IBooking.bookingID
            Get
                Return mBookingID
            End Get
            Set(value As Integer)
                mBookingID = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the topic ID.
        ''' </summary>
        ''' <value>
        ''' The topic ID.
        ''' </value>
        Public Property TopicID As Integer Implements Utilities.IBooking.topicID
            Get
                Return mTopicID
            End Get
            Set(value As Integer)
                mTopicID = value
            End Set
        End Property


        ''' <summary>
        ''' Gets or sets the date of appearance.
        ''' </summary>
        ''' <value>
        ''' The date of appearance.
        ''' </value>
        Public Property dateOfAppearance As Date Implements Utilities.IBooking.dateOfAppearance
            Get
                Return mBookingDate
            End Get
            Set(value As Date)
                mBookingDate = value
            End Set
        End Property


        ''' <summary>
        ''' Gets or sets the date of booking.
        ''' </summary>
        ''' <value>
        ''' The date of booking.
        ''' </value>
        Public Property DateOfBooking As Date Implements Utilities.IBooking.DateOfBooking
            Get
                Return mCreationDate
            End Get
            Set(value As Date)
                mCreationDate = value
            End Set
        End Property


        ''' <summary>
        ''' Gets or sets the status.
        ''' </summary>
        ''' <value>
        ''' The status.
        ''' </value>
        Public Property status As String Implements Utilities.IBooking.status
            Get
                Return mStatus
            End Get
            Set(value As String)
                mStatus = value
            End Set
        End Property


        ''' <summary>
        ''' Gets or sets the teacher ID.
        ''' </summary>
        ''' <value>
        ''' The teacher ID.
        ''' </value>
        Public Property teacherID As Integer Implements Utilities.IBooking.teacherID
            Get
                Return mTeacherID
            End Get
            Set(value As Integer)
                mTeacherID = value
            End Set
        End Property


        ''' <summary>
        ''' Gets or sets the volunteer ID.
        ''' </summary>
        ''' <value>
        ''' The volunteer ID.
        ''' </value>
        Public Property volunteerID As Integer Implements Utilities.IBooking.volunteerID
            Get
                Return mvolunteerID
            End Get
            Set(value As Integer)
                mvolunteerID = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the name of the topic.
        ''' </summary>
        ''' <value>
        ''' The name of the topic.
        ''' </value>
        Public Property TopicName As String Implements Utilities.IBooking.topicName
            Get
                Return mTopicName
            End Get
            Set(value As String)
                mTopicName = value
            End Set
        End Property

        ''' <summary>
        ''' Gets a value indicating whether this instance is complete.
        ''' </summary>
        ''' <value>
        ''' 
        ''' <c>true</c> if this instance is complete; otherwise, <c>false</c>.
        ''' 
        ''' </value>
        Friend ReadOnly Property isComplete As Boolean
            Get
                If BookingID = 0 OrElse
                    teacherID = 0 OrElse
                    volunteerID = 0 OrElse
                    DateOfBooking = New Date OrElse
                    dateOfAppearance = New Date Then
                    Return False
                End If
                Return True
            End Get

        End Property

#End Region

#Region "Methods"

        ''' <summary>
        ''' Initializes a new instance of the <see cref="Booking" /> class.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Sends the specified booking.
        ''' </summary>
        ''' <param name="xBooking">The booking.</param><returns></returns>
        Public Shared Function Send(xBooking As Booking) As Boolean
            Return BookingSQL.Send(xBooking)
        End Function

        ''' <summary>
        ''' Creates this instance.
        ''' </summary><returns></returns>
        Public Shared Function Create() As Booking
            Return New Booking
        End Function

        ''' <summary>
        ''' Creates the specified booking with ID.
        ''' </summary>
        ''' <param name="bookingID">The booking ID.</param><returns></returns>
        Public Shared Function Create(bookingID As Integer) As Booking
            If bookingID = 0 Then
                Throw New ArgumentException("Booking ID is invalid")
            End If

            Dim table As DataTable = BookingSQL.Retrieve(CShort(bookingID))

            If table.Rows.Count() = 0 Then
                Throw New DataException("No results.")
            End If

            Dim lst As List(Of Booking) = Repackager(table)
            Dim booking As Booking = lst.Item(0)
            Return booking
        End Function

        ''' <summary>
        ''' Updates the specified booking.
        ''' </summary>
        ''' <param name="xBooking">The booking.</param><returns></returns>
        Public Shared Function update(xBooking As Booking) As Boolean
            Return BookingSQL.Modify(xBooking)
        End Function

        ''' <summary>
        ''' Gets the bookings.
        ''' </summary>
        ''' <param name="VolID">The volunteer ID.</param><returns></returns>
        Public Shared Function getBookings(Optional VolID As Integer = 0) As List(Of Booking)
            If VolID = 0 Then
                Dim dt As DataTable = BookingSQL.getAllBookings()
                Return Repackager(dt)
            Else
                Dim dt As DataTable = BookingSQL.Retrieve(VolID)
                Return Repackager(dt)
            End If
        End Function


#End Region

#Region "Repackager"
        ''' <summary>
        ''' Repackages the specified table.
        ''' </summary>
        ''' <param name="table">The table.</param>
        ''' <param name="type">The type.</param><returns></returns>
        Private Shared Function Repackager(table As DataTable, Optional type As RetrieveType = RetrieveType.EntireFile) As List(Of Booking)
            Dim booking As Booking = Nothing
            Dim lst As New List(Of Booking)

            For i = 0 To table.Rows.Count - 1
                booking = booking.Create()
                booking.blnTrustedSource = True
                booking.BookingID = CInt(table.Rows(i).Item("bookingID"))
                booking.teacherID = CInt(table.Rows(i).Item("teacherID"))
                booking.volunteerID = CInt(table.Rows(i).Item("volunteerID"))
                booking.DateOfBooking = CDate(table.Rows(i).Item("dateOfBooking"))
                booking.dateOfAppearance = CDate(table.Rows(i).Item("status"))
                lst.Insert((lst.Count), booking)
            Next

            booking.blnTrustedSource = False
            Return lst

        End Function
#End Region

#End Region

    End Class

End Namespace


