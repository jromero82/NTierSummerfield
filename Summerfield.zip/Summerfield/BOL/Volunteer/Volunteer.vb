﻿Option Strict On

Imports Summerfield.SQLBuilder
Imports Summerfield.Utilities

Namespace Summerfield.BOL

    Public Class Volunteer
        Implements IVolunteer

        Shared blnTrustedSource As Boolean
        Private mVolunteerID As Integer
        Private mFirstName As String
        Private mLastName As String
        Private mAddress As String
        Private mCity As String
        Private mProvince As String
        Private mPostalCode As String
        Private mPhoneNumber As String
        Private mEmail As String
        Private mAvailability As String
        Private mNotes As String
        Private mTopic As String

        Shared Sub New()
        End Sub

#Region "Properties"

        ''' <summary>
        ''' Gets or sets the volunteer ID.
        ''' </summary>
        ''' <value>
        ''' The volunteer ID.
        ''' </value>
        Public Property VolunteerID As Integer Implements IVolunteer.VolunteerID
            Get
                Return mVolunteerID
            End Get
            Set(value As Int32)
                mVolunteerID = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the first name.
        ''' </summary>
        ''' <value>
        ''' The first name.
        ''' </value>
        Public Property firstName As String Implements IVolunteer.FirstName
            Get
                Return mFirstName
            End Get
            Set(value As String)
                mFirstName = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the last name.
        ''' </summary>
        ''' <value>
        ''' The last name.
        ''' </value>
        Public Property lastName As String Implements IVolunteer.LastName
            Get
                Return mLastName
            End Get
            Set(value As String)
                mLastName = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the address.
        ''' </summary>
        ''' <value>
        ''' The address.
        ''' </value>
        Public Property address As String Implements IVolunteer.Address
            Get
                Return mAddress
            End Get
            Set(value As String)
                mAddress = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the city.
        ''' </summary>
        ''' <value>
        ''' The city.
        ''' </value>
        Public Property city As String Implements IVolunteer.City
            Get
                Return mCity
            End Get
            Set(value As String)
                mCity = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the province.
        ''' </summary>
        ''' <value>
        ''' The province.
        ''' </value>
        Public Property province As String Implements IVolunteer.Province
            Get
                Return mProvince
            End Get
            Set(value As String)
                mProvince = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the postal code.
        ''' </summary>
        ''' <value>
        ''' The postal code.
        ''' </value>
        Public Property postalCode As String Implements IVolunteer.PostalCode
            Get
                Return mPostalCode
            End Get
            Set(value As String)
                mPostalCode = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the phone number.
        ''' </summary>
        ''' <value>
        ''' The phone number.
        ''' </value>
        Public Property phoneNumber As String Implements IVolunteer.PhoneNumber
            Get
                Return mPhoneNumber
            End Get
            Set(value As String)
                mPhoneNumber = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the email.
        ''' </summary>
        ''' <value>
        ''' The email.
        ''' </value>
        Public Property email As String Implements IVolunteer.Email
            Get
                Return mEmail
            End Get
            Set(value As String)
                mEmail = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the availability.
        ''' </summary>
        ''' <value>
        ''' The availability.
        ''' </value>
        Public Property availability As String Implements IVolunteer.Availability
            Get
                Return mAvailability
            End Get
            Set(value As String)
                mAvailability = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the notes.
        ''' </summary>
        ''' <value>
        ''' The notes.
        ''' </value>
        Public Property notes As String Implements IVolunteer.Notes
            Get
                Return mNotes
            End Get
            Set(value As String)
                mNotes = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the topic.
        ''' </summary>
        ''' <value>
        ''' The topic.
        ''' </value>
        Public Property Topic As String Implements IVolunteer.Topic
            Get
                Return mTopic
            End Get
            Set(value As String)
                mTopic = value
            End Set
        End Property
#End Region

#Region "Volunteer Factory"

        ''' <summary>
        ''' Deletes the specified volunteer ID.
        ''' </summary>
        ''' <param name="volunteerID">The volunteer ID.</param><returns></returns>
        Public Shared Function delete(volunteerID As Integer) As Boolean
            Return VolunteerSQL.DeleteVolunteer(volunteerID)
        End Function

        ''' <summary>
        ''' Creates this instance.
        ''' </summary><returns></returns>
        Public Shared Function Create() As Volunteer
            Return New Volunteer
        End Function

        ''' <summary>
        ''' Creates the specified volunteer ID.
        ''' </summary>
        ''' <param name="VolunteerID">The volunteer ID.</param><returns></returns>
        Public Shared Function Create(ByVal VolunteerID As Integer) As Volunteer
            Dim DT As DataTable = VolunteerSQL.getVolunteer(VolunteerID)
            If DT.Rows.Count > 0 Then
                Dim VolList As List(Of Volunteer) = ConvertDT(DT)
                Dim vol As Volunteer = VolList(0)
                Return vol
            Else
                Throw New DataException("Volunteer not found")
            End If
        End Function

        ''' <summary>
        ''' Edits the volunteer.
        ''' </summary>
        ''' <param name="vol">The vol.</param><returns></returns>
        Public Shared Function EditVolunteer(vol As Volunteer) As Boolean
            Return VolunteerSQL.modifyVolunteer(vol)
        End Function

        ''' <summary>
        ''' Adds the volunteer topic.
        ''' </summary>
        ''' <param name="volID">The vol ID.</param>
        ''' <param name="topicID">The topic ID.</param><returns></returns>
        Public Shared Function addVolunteerTopic(volID As Integer, topicID As Integer) As Boolean
            VolunteerSQL.addVolunteerTopic(volID, topicID)
            Return True
        End Function

        
        ''' <summary>
        ''' Deletes the volunteer topic.
        ''' </summary>
        ''' <param name="volid">The volid.</param>
        ''' <param name="topicid">The topicid.</param><returns></returns>
        Public Shared Function deleteVolunteerTopic(volid As Integer, topicid As Integer) As Boolean
            VolunteerSQL.deleteVolunteerTopic(volid, topicid)
            Return True
        End Function

        ''' <summary>
        ''' Converts the datatable.
        ''' </summary>
        ''' <param name="DT">The datatable.</param>
        ''' <param name="type">The type.</param><returns></returns>
        Friend Shared Function ConvertDT(ByVal DT As DataTable, Optional ByVal type As RetrieveType = RetrieveType.EntireFile) As List(Of Volunteer)
            Dim newVolunteerList As New List(Of Volunteer)
            For i As Int32 = 0 To DT.Rows.Count - 1
                Dim newVol As Volunteer = New Volunteer
                blnTrustedSource = True
                newVol.VolunteerID = CInt(DT.Rows(i).Item("volunteerID"))
                newVol.firstName = CStr(DT.Rows(i).Item("firstName"))
                newVol.lastName = CStr(DT.Rows(i).Item("lastName"))
                newVol.address = CStr(DT.Rows(i).Item("address"))
                newVol.city = CStr(DT.Rows(i).Item("city"))
                newVol.province = CStr(DT.Rows(i).Item("province"))
                newVol.postalCode = CStr(DT.Rows(i).Item("postalCode"))
                newVol.phoneNumber = CStr(DT.Rows(i).Item("phoneNumber"))
                newVol.email = CStr(DT.Rows(i).Item("email"))
                newVol.availability = CStr(DT.Rows(i).Item("availability"))
                If DT.Rows(i).Item("notes") Is Nothing Then
                    newVol.notes = Nothing
                Else
                    newVol.notes = CStr(DT.Rows(i).Item("notes"))
                End If

                blnTrustedSource = False
                newVolunteerList.Add(newVol)
            Next
            Return newVolunteerList

        End Function

#End Region


    End Class


End Namespace