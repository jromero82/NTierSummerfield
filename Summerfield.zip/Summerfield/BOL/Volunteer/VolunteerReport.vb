﻿Option Strict On

Imports Summerfield.SQLBuilder


Namespace Summerfield.BOL
    Public Class VolunteerReport

        Private mFullname As String
        Private mAddress As String
        Private mPhone As String
        Private mEmail As String

#Region "Properties"

        ''' <summary>
        ''' Gets or sets the full name.
        ''' </summary>
        ''' <value>
        ''' The full name.
        ''' </value>
        Public Property FullName As String
            Get
                Return mFullname
            End Get
            Set(value As String)
                mFullname = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the address.
        ''' </summary>
        ''' <value>
        ''' The address.
        ''' </value>
        Public Property Address As String
            Get
                Return mAddress
            End Get
            Set(value As String)
                mAddress = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the phone.
        ''' </summary>
        ''' <value>
        ''' The phone.
        ''' </value>
        Public Property Phone As String
            Get
                Return mPhone
            End Get
            Set(value As String)
                mPhone = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the email.
        ''' </summary>
        ''' <value>
        ''' The email.
        ''' </value>
        Public Property Email As String
            Get
                Return mEmail
            End Get
            Set(value As String)
                mEmail = value
            End Set
        End Property

#End Region

        ''' <summary>
        ''' Reports the volunteers.
        ''' </summary><returns></returns>
        Public Shared Function reportVolunteers() As List(Of VolunteerReport)
            Dim dt As DataTable = VolunteerSQL.reportVolunteers()
            Return Repackager(dt)
        End Function

        ''' <summary>
        ''' Reports the active volunteers.
        ''' </summary><returns></returns>
        Public Shared Function reportActiveVolunteers() As List(Of VolunteerReport)
            Dim dt As DataTable = VolunteerSQL.reportActiveVolunteers()
            Return Repackager(dt)
        End Function

        ''' <summary>
        ''' Repackages the specified datatable.
        ''' </summary>
        ''' <param name="DT">The DT.</param><returns></returns>
        Friend Shared Function Repackager(ByVal DT As DataTable) As List(Of VolunteerReport)
            Dim newVolunteerList As New List(Of VolunteerReport)
            For i As Int32 = 0 To DT.Rows.Count - 1
                Dim newVol As VolunteerReport = New VolunteerReport
                newVol.Fullname = CStr(DT.Rows(i).Item("FullName"))
                newVol.Address = CStr(DT.Rows(i).Item("Address"))
                newVol.Phone = CStr(DT.Rows(i).Item("PhoneNumber"))
                newVol.Email = CStr(DT.Rows(i).Item("Email"))
                newVolunteerList.Add(newVol)
            Next
            Return newVolunteerList

        End Function

    End Class
End Namespace