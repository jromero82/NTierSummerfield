﻿Option Strict On
Imports Summerfield.Utilities
Imports Summerfield.SQLBuilder
Imports Summerfield.BOL

Namespace Summerfield.BOL
    Public Class VolunteerList

        Public Property VolunteerID As Integer
        Public Property FullName As String

        ''' <summary>
        ''' Volunteers the lookup.
        ''' </summary><returns></returns>
        Public Shared Function VolunteerLookup() As List(Of VolunteerList)
            Dim dt As DataTable = VolunteerSQL.getAllVolunteers()
            Return ConvertDT(dt, RetrieveType.LookupTable)
        End Function

        ''' <summary>
        ''' Searches the specified parameter.
        ''' </summary>
        ''' <param name="parameter">The parameter.</param>
        ''' <param name="type">The type.</param><returns></returns>
        Public Shared Function Search(parameter As String, type As SearchParm) As List(Of VolunteerList)
            If type = SearchParm.SearchByKeyword Then
                Return ConvertDT(VolunteerSQL.getVolunteersByKeyword(parameter))
            ElseIf type = SearchParm.SearchByName Then
                Return ConvertDT(VolunteerSQL.getVolunteerByPartialName(parameter))
            Else
                Return ConvertDT(VolunteerSQL.getVolunteerByTopic(parameter))
            End If
        End Function

        ''' <summary>
        ''' Converts the datatable.
        ''' </summary>
        ''' <param name="DT">The datatable.</param>
        ''' <param name="type">The type.</param><returns></returns>
        Friend Shared Function ConvertDT(ByVal DT As DataTable, Optional ByVal type As RetrieveType = RetrieveType.EntireFile) As List(Of VolunteerList)

            Dim newVolunteerList As New List(Of VolunteerList)
            For i As Int32 = 0 To DT.Rows.Count - 1
                Dim newVol As VolunteerList = New VolunteerList

                newVol.VolunteerID = CInt(DT.Rows(i).Item("volunteerID"))
                newVol.FullName = CStr(DT.Rows(i).Item("FullName"))

                newVolunteerList.Add(newVol)
            Next
            Return newVolunteerList

        End Function
    End Class
End Namespace