﻿Option Strict On

Imports Summerfield.SQLBuilder

Namespace Summerfield.BOL
    ''' <summary>
    ''' Class for logins
    ''' </summary>
    Public Class Login

        Private mUsername As String
        Private mPassword As String
        Private mAdmin As Boolean

#Region "Properties"

        ''' <summary>
        ''' Gets or sets the username.
        ''' </summary>
        ''' <value>
        ''' The username.
        ''' </value>
        Public Property Username As String
            Get
                Return mUsername
            End Get
            Set(value As String)
                mUsername = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the password.
        ''' </summary>
        ''' <value>
        ''' The password.
        ''' </value>
        Public Property Password As String
            Get
                Return mPassword
            End Get
            Set(value As String)
                mPassword = value
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets a value indicating whether this <see cref="Login" /> is admin.
        ''' </summary>
        ''' <value>
        '''   <c>true</c> if admin; otherwise, <c>false</c>.
        ''' </value>
        Public Property Admin As Boolean
            Get
                Return mAdmin
            End Get
            Set(value As Boolean)
                mAdmin = value
            End Set
        End Property

#End Region

        ''' <summary>
        ''' Checks the login.
        ''' </summary>
        ''' <param name="username">The username.</param>
        ''' <param name="password">The password.</param><returns></returns>
        Public Shared Function checkLogin(username As String, password As String) As ArrayList
            Dim lstResults As ArrayList = LoginSQL.checklogin(username, password)
            Return lstResults
        End Function


    End Class
End Namespace