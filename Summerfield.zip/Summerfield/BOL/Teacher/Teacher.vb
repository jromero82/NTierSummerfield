﻿Option Strict On

Imports Summerfield.Utilities
Imports Summerfield.SQLBuilder

Namespace Summerfield.BOL

    ''' <summary>
    ''' The class for Teachers
    ''' </summary>
    Public Class Teacher
        Implements ITeacher

#Region "Factory"

#Region "Properties"

        Dim blnTrustedSource As Boolean

        Private _teacherId As Integer
        ''' <summary>
        ''' Gets or sets the teacher ID.
        ''' </summary>
        ''' <value>
        ''' The teacher ID.
        ''' </value>
        Public Property teacherID As Integer Implements Utilities.ITeacher.teacherID
            Get
                Return _teacherId
            End Get
            Set(value As Integer)
                _teacherId = value
            End Set
        End Property

        Private _email As String
        ''' <summary>
        ''' Gets or sets the email.
        ''' </summary>
        ''' <value>
        ''' The email.
        ''' </value>
        Public Property email As String Implements Utilities.ITeacher.email
            Get
                Return _email
            End Get
            Set(value As String)
                If blnTrustedSource Then
                    _email = value
                    Exit Property
                End If

                If Validate.isValidEmail(value) Then
                    _email = value
                End If

            End Set
        End Property

        Private _firstName As String
        ''' <summary>
        ''' Gets or sets the first name.
        ''' </summary>
        ''' <value>
        ''' The first name.
        ''' </value>
        Public Property firstName As String Implements Utilities.ITeacher.firstName
            Get
                Return _firstName
            End Get
            Set(value As String)
                If blnTrustedSource Then
                    _firstName = value
                    Exit Property
                End If

                If Validate.ValidateStringValue(value, CheckStringValue.MustNotBeNullorEmpty, "First name") Then
                    If Validate.ValidateFieldLength(value, 20, "First name", SizeOperator.CanBeLessThan) Then
                        _firstName = value
                    End If
                End If

            End Set
        End Property

        Private _lastName As String
        ''' <summary>
        ''' Gets or sets the last name.
        ''' </summary>
        ''' <value>
        ''' The last name.
        ''' </value>
        Public Property lastName As String Implements Utilities.ITeacher.lastName
            Get
                Return _lastName
            End Get
            Set(value As String)
                If blnTrustedSource Then
                    _lastName = value
                    Exit Property
                End If

                If Validate.ValidateStringValue(value, CheckStringValue.MustNotBeNullorEmpty, "Last name") Then
                    If Validate.ValidateFieldLength(value, 30, "Last name", SizeOperator.CanBeLessThan) Then
                        _lastName = value
                    End If
                End If

            End Set
        End Property

        Private _password As String
        ''' <summary>
        ''' Gets or sets the password.
        ''' </summary>
        ''' <value>
        ''' The password.
        ''' </value>
        Public Property password As String Implements Utilities.ITeacher.password
            Get
                Return _password
            End Get
            Set(value As String)
                If Validate.ValidateFieldLength(value, 20, "Password", SizeOperator.CanBeLessThan) Then
                    _password = value
                End If
            End Set
        End Property

        Private _phoneNumber As String
        ''' <summary>
        ''' Gets or sets the phone number.
        ''' </summary>
        ''' <value>
        ''' The phone number.
        ''' </value>
        Public Property phoneNumber As String Implements Utilities.ITeacher.phoneNumber
            Get
                Return _phoneNumber
            End Get
            Set(value As String)
                If Validate.ValidateStringValue(value, CheckStringValue.MustBeNumeric, "Phone number") Then
                    If Validate.ValidateFieldLength(value, 10, "Phone number", SizeOperator.CanBeLessThan) Then
                        _phoneNumber = value
                    End If
                End If

            End Set
        End Property

        Private _admin As Boolean
        ''' <summary>
        ''' Gets or sets a value indicating whether this <see cref="Teacher" /> is admin.
        ''' </summary>
        ''' <value>
        '''   <c>true</c> if admin; otherwise, <c>false</c>.
        ''' </value>
        Public Property admin As Boolean Implements Utilities.ITeacher.admin
            Get
                Return _admin
            End Get
            Set(value As Boolean)
                _admin = value
            End Set
        End Property

        ''' <summary>
        ''' Gets a value indicating whether this instance is complete.
        ''' </summary>
        ''' <value>
        ''' 
        ''' <c>true</c> if this instance is complete; otherwise, <c>false</c>.
        ''' 
        ''' </value>
        Friend ReadOnly Property isComplete As Boolean
            Get
                If firstName = String.Empty OrElse
                    lastName = String.Empty OrElse
                    password = String.Empty OrElse
                    email = String.Empty OrElse
                    phoneNumber = String.Empty OrElse
                    password = String.Empty Then

                    Return False
                End If

                Return True

            End Get
        End Property

#End Region

#Region "Methods"

        ''' <summary>
        ''' Prevents a default instance of the <see cref="Teacher" /> class from being created.
        ''' </summary>
        Private Sub New()
        End Sub

        ''' <summary>
        ''' Creates this instance.
        ''' </summary><returns></returns>
        Public Shared Function Create() As Teacher
            Return New Teacher
        End Function

        ''' <summary>
        ''' Creates the specified teacher id.
        ''' </summary>
        ''' <param name="teacherId">The teacher id.</param><returns></returns>
        Public Shared Function Create(teacherId As Integer) As Teacher

            If teacherId = 0 Then
                Throw New ArgumentException("Teacher ID is invalid")
            End If

            Dim table As DataTable = TeacherSQL.Retrieve(teacherId)

            If table.Rows.Count() = 0 Then
                Throw New DataException("No results.")
            End If

            Dim lst As List(Of Teacher) = Repackager(table)
            Dim teacher As Teacher = lst.Item(0)
            Return teacher

        End Function


#End Region

#Region "Repackager"

        ''' <summary>
        ''' Repackages the specified table.
        ''' </summary>
        ''' <param name="table">The table.</param>
        ''' <param name="type">The type.</param><returns></returns>
        Friend Shared Function Repackager(table As DataTable, Optional type As RetrieveType = RetrieveType.EntireFile) As List(Of Teacher)
            Dim teacher As Teacher = Nothing
            Dim lst As New List(Of Teacher)

            If type = RetrieveType.LookupTable Then
                For i = 0 To table.Rows.Count - 1
                    teacher = teacher.Create()
                    teacher.blnTrustedSource = True
                    teacher.teacherID = Convert.ToInt16(table.Rows(i).Item("teacherID"))
                    teacher.lastName = table.Rows(i).Item("fullname").ToString
                    lst.Insert((lst.Count), teacher)
                Next
            Else
                For i = 1 To table.Rows.Count

                    teacher = New Teacher
                    teacher.blnTrustedSource = True
                    teacher.teacherID = Convert.ToInt16(table.Rows(0).Item("teacherID").ToString)
                    teacher.firstName = table.Rows(0).Item("firstName").ToString
                    teacher.lastName = table.Rows(0).Item("lastName").ToString
                    teacher.password = table.Rows(0).Item("password").ToString
                    teacher.email = table.Rows(0).Item("email").ToString
                    teacher.phoneNumber = table.Rows(0).Item("phoneNumber").ToString
                    teacher.admin = Convert.ToBoolean(table.Rows(0).Item("admin"))

                    lst.Insert((lst.Count), teacher)
                Next
            End If

            teacher.blnTrustedSource = False
            Return lst
        End Function

#End Region

#End Region

    End Class

End Namespace