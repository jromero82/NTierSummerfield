﻿Option Strict On
Imports Summerfield.Utilities
Imports Summerfield.SQLBuilder

Namespace Summerfield.BOL

    ''' <summary>
    ''' Class for the Teacher Lists
    ''' </summary>
    Public Class TeacherLists

        Public Property TeacherId As Integer
        Public Property FullName As String

        ''' <summary>
        ''' Prevents a default instance of the <see cref="TeacherLists" /> class from being created.
        ''' </summary>
        Private Sub New()
        End Sub

        ''' <summary>
        ''' Retrieves the teacher list.
        ''' </summary>
        ''' <param name="type">The type.</param><returns></returns>
        Public Shared Function RetrieveTeacherList(ByVal type As RetrieveType) As List(Of TeacherLists)

            Dim lst As List(Of TeacherLists) = Nothing
            If type = RetrieveType.LookupTable Then
                Dim dt As DataTable = TeacherSQL.getAllTeachers()
                lst = ConvertDT(dt)
            End If
            Return lst

        End Function

        ''' <summary>
        ''' Reports all teachers.
        ''' </summary><returns></returns>
        Public Shared Function reportAllTeachers() As List(Of TeacherLists)
            Dim lst As List(Of TeacherLists) = Nothing
            Dim dt As DataTable = TeacherSQL.getAllTeachers()
                lst = ConvertDT(dt)

            Return lst
        End Function

        ''' <summary>
        ''' Converts the Datatable into a Lists of Teachers.
        ''' </summary>
        ''' <param name="dt">The dt.</param><returns></returns>
        Private Shared Function ConvertDT(dt As DataTable) As List(Of TeacherLists)
            Dim newTeacherList As New List(Of TeacherLists)
            For i As Integer = 0 To dt.Rows.Count - 1
                Dim newTeacher As TeacherLists = New TeacherLists

                newTeacher.TeacherId = Convert.ToInt16(dt.Rows(i).Item("TeacherID"))
                newTeacher.FullName = dt.Rows(i).Item("FullName").ToString()

                newTeacherList.Add(newTeacher)
            Next
            Return newTeacherList

        End Function

    End Class


End Namespace
