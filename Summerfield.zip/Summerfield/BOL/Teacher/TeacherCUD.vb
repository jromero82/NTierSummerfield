﻿Option Strict On
Imports Summerfield.SQLBuilder
Imports Summerfield.Utilities

Namespace Summerfield.BOL

    ''' <summary>
    ''' Teacher Create, Update, and Delete
    ''' </summary>
    Public Class TeacherCUD
#Region "Insert, Update, and Delete Methods"

        ''' <summary>
        ''' Deletes the specified teacher.
        ''' </summary>
        ''' <param name="teacherID">The teacher ID.</param><returns></returns>
        Public Shared Function Delete(teacherID As Integer) As Boolean

            If teacherID = 0 Then
                Throw New ArgumentException("Teacher Id is invalid")
            End If

            Return TeacherSQL.Delete(CStr(teacherID))
        End Function

        ''' <summary>
        ''' Inserts the specified teacher.
        ''' </summary>
        ''' <param name="teacher">The teacher.</param><returns></returns>
        Public Shared Function Insert(teacher As Teacher) As Boolean
            If teacher.isComplete = False Then
                Throw New ArgumentException("Teacher not valid")
            End If
            Return TeacherSQL.Add(DirectCast(teacher, ITeacher))
        End Function

        ''' <summary>
        ''' Updates the specified teacher.
        ''' </summary>
        ''' <param name="teacher">The teacher.</param><returns></returns>
        Public Shared Function Update(teacher As Teacher) As Boolean
            If teacher.isComplete = False Then
                Throw New ArgumentException("Teacher not valid")
            End If
            Return TeacherSQL.Modify(DirectCast(teacher, ITeacher))
        End Function

#End Region
    End Class

End Namespace
