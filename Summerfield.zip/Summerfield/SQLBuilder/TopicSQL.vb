﻿Option Strict On

Imports SDC = System.Data.Common
Imports Summerfield.Data
Imports Summerfield.Utilities

Namespace Summerfield.SQLBuilder

    Public Class TopicSQL

        ''' <summary>
        ''' Deletes the topic.
        ''' </summary>
        ''' <param name="TopicID">The topic ID.</param><returns></returns>
        Public Shared Function DeleteTopic(ByVal TopicID As Integer) As Boolean
            Dim parmList As New List(Of Parm)
            parmList.Add(New Parm("@TopicID", TopicID, ParameterDirection.Input, DbType.Int16))
            DAL.UpdateData("deleteTopic", parmList)
            Return True
        End Function

        ''' <summary>
        ''' Gets the volunteer topic.
        ''' </summary>
        ''' <param name="volunteerid">The volunteerid.</param><returns></returns>
        Public Shared Function getVolunteerTopic(volunteerid As Integer) As DataTable
            Dim parmList As New List(Of Parm)
            parmList.Add(New Parm("@volunteerid", volunteerid, ParameterDirection.Input, DbType.Int16))
            Return DAL.GetDataTable("getVolunteerTopic", parmList)
        End Function

        ''' <summary>
        ''' Retrieves the topic.
        ''' </summary>
        ''' <param name="TopicID">The topic ID.</param><returns></returns>
        Public Shared Function RetrieveTopic(Optional ByVal TopicID As Integer = 0) As DataTable
            If TopicID = 0 Then
                Return DAL.GetDataTable("getAllTopics")
            Else
                Dim parmList As New List(Of Parm)
                parmList.Add(New Parm("@TopicID", TopicID, ParameterDirection.Input, DbType.Int16))
                Return DAL.GetDataTable("getTopic", parmList)
            End If
        End Function

        ''' <summary>
        ''' Adds the topic.
        ''' </summary>
        ''' <param name="top">The top.</param><returns></returns>
        Public Shared Function addTopic(top As String) As Boolean
            Try
                Dim parmList As New List(Of Parm)
                parmList.Add(New Parm("@TopicName", top, ParameterDirection.Input, DbType.String, 25))
                DAL.UpdateData("addTopic", parmList)
            Catch ex As Exception
                Throw New DataException(ex.Message)
            End Try

            Return True
        End Function

        ''' <summary>
        ''' Modifies the topic.
        ''' </summary>
        ''' <param name="top">The top.</param><returns></returns>
        Public Shared Function modifyTopic(top As ITopic) As Boolean
            Dim parmList As New List(Of Parm)
            parmList.Add(New Parm("@topicID", top.TopicID, ParameterDirection.Input, DbType.Int16))
            parmList.Add(New Parm("@TopicName", top.TopicName, ParameterDirection.Input, DbType.String, 25))

            DAL.UpdateData("modifyTopic", parmList)
            Return True
        End Function

        ''' <summary>
        ''' Gets the volunteer topics.
        ''' </summary><returns></returns>
        Public Shared Function getVolunteerTopics() As DataTable
            Return DAL.GetDataTable("reportVolunteerTopics")
        End Function

    End Class

End Namespace

