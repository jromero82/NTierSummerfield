﻿Option Strict On

Imports SDC = System.Data.Common
Imports Summerfield.Data
Imports Summerfield.Utilities

Namespace Summerfield.SQLBuilder

    Public Class TeacherSQL

#Region "CRUD"

        ''' <summary>
        ''' Adds the specified teacher.
        ''' </summary>
        ''' <param name="teacher">The teacher.</param><returns></returns>
        Public Shared Function Add(teacher As ITeacher) As Boolean

            Dim parmList As New List(Of Parm)
            parmList.Add(New Parm("@teacherId", teacher.teacherID, ParameterDirection.Output, DbType.Int16))
            parmList.Add(New Parm("@firstname", teacher.firstName, ParameterDirection.Input, DbType.String, 20))
            parmList.Add(New Parm("@lastname", teacher.lastName, ParameterDirection.Input, DbType.String, 30))
            parmList.Add(New Parm("@password", teacher.password, ParameterDirection.Input, DbType.String, 20))
            parmList.Add(New Parm("@email", teacher.email, ParameterDirection.Input, DbType.String, 20))
            parmList.Add(New Parm("@phoneNumber", teacher.phoneNumber, ParameterDirection.Input, DbType.StringFixedLength, 10))
            parmList.Add(New Parm("@admin", teacher.admin, ParameterDirection.Input, DbType.Boolean))

            DAL.UpdateData("addTeachers", parmList)
            teacher.teacherID = Convert.ToInt16(parmList.Item(0).parmValue)

            Return True

        End Function

        ''' <summary>
        ''' Deletes the specified teacher ID.
        ''' </summary>
        ''' <param name="teacherID">The teacher ID.</param><returns></returns>
        Public Shared Function Delete(teacherID As String) As Boolean

            Dim parmList As New List(Of Parm)
            parmList.Add(New Parm("@teacherID", teacherID, ParameterDirection.Input, DbType.StringFixedLength, 4))
            DAL.UpdateData("deleteTeacher", parmList)
            Return True

        End Function

        ''' <summary>
        ''' Modifies the specified teacher.
        ''' </summary>
        ''' <param name="teacher">The teacher.</param><returns></returns>
        Public Shared Function Modify(teacher As ITeacher) As Boolean

            Dim parmList As New List(Of Parm)
            parmList.Add(New Parm("@teacherId", teacher.teacherID, ParameterDirection.Input, DbType.Int16))
            parmList.Add(New Parm("@firstname", teacher.firstName, ParameterDirection.Input, DbType.String, 20))
            parmList.Add(New Parm("@lastname", teacher.lastName, ParameterDirection.Input, DbType.String, 30))
            parmList.Add(New Parm("@password", teacher.password, ParameterDirection.Input, DbType.String, 20))
            parmList.Add(New Parm("@email", teacher.email, ParameterDirection.Input, DbType.String, 20))
            parmList.Add(New Parm("@phoneNumber", teacher.phoneNumber, ParameterDirection.Input, DbType.StringFixedLength, 10))
            parmList.Add(New Parm("@admin", teacher.admin, ParameterDirection.Input, DbType.Boolean))

            DAL.UpdateData("modifyTeacher", parmList)
            Return True

        End Function

        ''' <summary>
        ''' Retrieves the specified teacher ID.
        ''' </summary>
        ''' <param name="teacherID">The teacher ID.</param><returns></returns>
        Public Shared Function Retrieve(teacherID As Integer) As DataTable

            Dim parmList As New List(Of Parm)
            parmList.Add(New Parm("@teacherID", teacherID, ParameterDirection.Input, DbType.StringFixedLength, 4))

            Return DAL.GetDataTable("getTeacher", parmList)

        End Function

#End Region

#Region "Lists"

        ''' <summary>
        ''' Gets all teachers.
        ''' </summary><returns></returns>
        Shared Function getAllTeachers() As DataTable
            Return DAL.GetDataTable("getAllTeachers")
        End Function

#End Region


    End Class

End Namespace
