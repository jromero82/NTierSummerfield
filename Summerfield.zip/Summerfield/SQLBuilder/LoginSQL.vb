﻿Option Strict On

Imports Summerfield.Data
Imports Summerfield.Utilities

Namespace Summerfield.SQLBuilder
    Public Class LoginSQL

        ''' <summary>
        ''' Check the logins for specified username.
        ''' </summary>
        ''' <param name="username">The username.</param>
        ''' <param name="password">The password.</param><returns></returns>
        Public Shared Function checklogin(username As String, password As String) As ArrayList
            Dim result As Integer
            Dim teacherid As Integer
            Dim parmList As New List(Of Parm)
            parmList.Add(New Parm("@username", username, ParameterDirection.Input, DbType.String, 50))
            parmList.Add(New Parm("@password", password, ParameterDirection.Input, DbType.String, 50))
            parmList.Add(New Parm("@result", result, ParameterDirection.Output, DbType.Int32))
            parmList.Add(New Parm("@teacherid", teacherid, ParameterDirection.Output, DbType.Int32))
            DAL.UpdateData("checklogin", parmList)
            result = CInt(parmList.Item(2).parmValue)
            If Not IsDBNull(parmList.Item(3).parmValue) Then
                teacherid = CInt(parmList.Item(3).parmValue)
            End If
            Dim lstResults As New ArrayList
            lstResults.Add(result)
            lstResults.Add(teacherid)
            Return lstResults

        End Function

    End Class
End Namespace