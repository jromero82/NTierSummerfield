﻿Option Strict On
Imports SDC = System.Data.Common
Imports Summerfield.Data
Imports Summerfield.Utilities

Namespace Summerfield.SQLBuilder

    Public Class BookingSQL

#Region "CRUD"

        ''' <summary>
        ''' Creates the specified booking.
        ''' </summary>
        ''' <param name="booking">The booking.</param><returns></returns>
        Public Shared Function Create(booking As IBooking) As Boolean

            Dim parmList As New List(Of Parm)
            parmList.Add(New Parm("@teacherID", booking.teacherID, ParameterDirection.Input, DbType.Int16, 4))
            parmList.Add(New Parm("@volunteerID", booking.volunteerID, ParameterDirection.Input, DbType.Int16, 4))
            parmList.Add(New Parm("@dateOfAppearance", booking.dateOfAppearance, ParameterDirection.Input, DbType.Date))
            parmList.Add(New Parm("@topic", booking.topicID, ParameterDirection.Input, DbType.Int32))

            DAL.UpdateData("createBooking", parmList)
            Return True

        End Function

        ''' <summary>
        ''' Retrieves the specified volunteer ID.
        ''' </summary>
        ''' <param name="volID">The volunteer ID.</param><returns></returns>
        Public Shared Function Retrieve(volID As Integer) As DataTable

            Dim parmList As New List(Of Parm)
            parmList.Add(New Parm("@VolunteerID", volID, ParameterDirection.Input, DbType.Int32))
            Return DAL.GetDataTable("getVolunteerBooking", parmList)

        End Function

        ''' <summary>
        ''' Modifies the specified booking.
        ''' </summary>
        ''' <param name="booking">The booking.</param><returns></returns>
        Public Shared Function Modify(booking As IBooking) As Boolean

            Dim parmList As New List(Of Parm)
            parmList.Add(New Parm("@bookingID", booking.bookingID, ParameterDirection.Input, DbType.Int16, 4))
            parmList.Add(New Parm("@teacherID", booking.teacherID, ParameterDirection.Input, DbType.Int16, 4))
            parmList.Add(New Parm("@volunteerID", booking.volunteerID, ParameterDirection.Input, DbType.Int16, 4))
            parmList.Add(New Parm("@dateOfBooking", booking.DateOfBooking, ParameterDirection.Input, DbType.DateTime))
            parmList.Add(New Parm("@dateOfAppearance", booking.dateOfAppearance, ParameterDirection.Input, DbType.DateTime))
            parmList.Add(New Parm("@status", booking.status, ParameterDirection.Input, DbType.String))
            parmList.Add(New Parm("@topicID", booking.topicID, ParameterDirection.Input, DbType.Int32))
            Return DAL.UpdateData("modifyBooking", parmList)

        End Function

        ''' <summary>
        ''' Gets the teacher bookings.
        ''' </summary>
        ''' <param name="teacherid">The teacherid.</param><returns></returns>
        Public Shared Function getTeacherBookings(teacherid As Integer) As DataTable
            Dim parmList As New List(Of Parm)
            parmList.Add(New Parm("@teacherid", teacherid, ParameterDirection.Input, DbType.Int32))
            Return DAL.GetDataTable("getTeacherBooking", parmList)
        End Function

        ''' <summary>
        ''' Sends the specified booking.
        ''' </summary>
        ''' <param name="xBook">The booking.</param><returns></returns>
        Public Shared Function Send(xBook As IBooking) As Boolean
            Dim parmList As New List(Of Parm)
            parmList.Add(New Parm("@teacherID", xBook.teacherID, ParameterDirection.Input, DbType.Int16, 4))
            parmList.Add(New Parm("@volunteerID", xBook.volunteerID, ParameterDirection.Input, DbType.Int16, 4))
            parmList.Add(New Parm("@dateOfAppearance", xBook.dateOfAppearance, ParameterDirection.Input, DbType.DateTime))
            Return DAL.UpdateData("createBooking", parmList)
        End Function

#End Region

#Region "Lists"

        ''' <summary>
        ''' Gets all bookings.
        ''' </summary><returns></returns>
        Public Shared Function getAllBookings() As DataTable
            Return DAL.GetDataTable("getAllBookings")
        End Function

        ''' <summary>
        ''' Gets the booking by date.
        ''' </summary>
        ''' <param name="mindate">The mindate.</param>
        ''' <param name="maxdate">The maxdate.</param><returns></returns>
        Public Shared Function getBookingByDate(mindate As Date, maxdate As Date) As DataTable
            Dim parmlist As List(Of Parm) = New List(Of Parm)
            parmlist.Add(New Parm("@mindate", mindate, ParameterDirection.Input, DbType.Date))
            parmlist.Add(New Parm("@maxdate", maxdate, ParameterDirection.Input, DbType.Date))
            Return DAL.GetDataTable("getBookingByDate", parmlist)
        End Function

        ''' <summary>
        ''' Gets the booking by volunteer.
        ''' </summary>
        ''' <param name="volunteername">The volunteername.</param><returns></returns>
        Public Shared Function getBookingByVolunteer(volunteername As String) As DataTable
            Dim parmlist As List(Of Parm) = New List(Of Parm)
            parmlist.Add(New Parm("@volunteername", volunteername, ParameterDirection.Input, DbType.String, 50))
            Return DAL.GetDataTable("getBookingByVolunteerName", parmlist)
        End Function

        ''' <summary>
        ''' Gets the booking by teacher.
        ''' </summary>
        ''' <param name="teachername">The teachername.</param><returns></returns>
        Public Shared Function getBookingByTeacher(teachername As String) As DataTable
            Dim parmlist As List(Of Parm) = New List(Of Parm)
            parmlist.Add(New Parm("@teachername", teachername, ParameterDirection.Input, DbType.String, 50))
            Return DAL.GetDataTable("getBookingByTeacherName", parmlist)
        End Function

#End Region

    End Class

End Namespace

