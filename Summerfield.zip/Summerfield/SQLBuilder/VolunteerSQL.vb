﻿Option Strict On

Imports SDC = System.Data.Common
Imports Summerfield.Data
Imports Summerfield.Utilities

Namespace Summerfield.SQLBuilder

    Public Class VolunteerSQL

        ''' <summary>
        ''' Deletes the volunteer.
        ''' </summary>
        ''' <param name="VolunteerID">The volunteer ID.</param><returns></returns>
        Public Shared Function DeleteVolunteer(ByVal VolunteerID As Integer) As Boolean
            Dim parmList As New List(Of Parm)
            parmList.Add(New Parm("@VolunteerID", VolunteerID, ParameterDirection.Input, DbType.Int16))
            DAL.UpdateData("deleteVolunteer", parmList)
            Return True
        End Function

        ''' <summary>
        ''' Gets the volunteer.
        ''' </summary>
        ''' <param name="VolunteerID">The volunteer ID.</param><returns></returns>
        Public Shared Function getVolunteer(ByVal VolunteerID As Integer) As DataTable
            Dim parmList As New List(Of Parm)
            parmList.Add(New Parm("@VolunteerID", VolunteerID, ParameterDirection.Input, DbType.Int16))
            Return DAL.GetDataTable("getVolunteer", parmList)
        End Function

        ''' <summary>
        ''' Gets all volunteers.
        ''' </summary><returns></returns>
        Public Shared Function getAllVolunteers() As DataTable
            Return DAL.GetDataTable("getAllVolunteers")
        End Function

        ''' <summary>
        ''' Adds the volunteer.
        ''' </summary>
        ''' <param name="vol">The vol.</param><returns></returns>
        Public Shared Function addVolunteer(ByVal vol As IVolunteer) As Boolean
            Dim parmList As New List(Of Parm)
            parmList.Add(New Parm("@volunteerID", vol, ParameterDirection.Input, DbType.Int16))
            parmList.Add(New Parm("@fname", vol.FirstName, ParameterDirection.Input, DbType.String, 50))
            parmList.Add(New Parm("@lname", vol.LastName, ParameterDirection.Input, DbType.String, 50))
            parmList.Add(New Parm("@address", vol.Address, ParameterDirection.Input, DbType.String, 50))
            parmList.Add(New Parm("@city", vol.City, ParameterDirection.Input, DbType.String, 50))
            parmList.Add(New Parm("@province", vol.Province, ParameterDirection.Input, DbType.String, 10))
            parmList.Add(New Parm("@postalCode", vol.PostalCode, ParameterDirection.Input, DbType.String, 10))
            parmList.Add(New Parm("@phoneNumber", vol.PhoneNumber, ParameterDirection.Input, DbType.StringFixedLength, 10))
            parmList.Add(New Parm("@email", vol.Email, ParameterDirection.Input, DbType.String, 50))
            parmList.Add(New Parm("@availability", vol.Availability, ParameterDirection.Input, DbType.String, 100))
            parmList.Add(New Parm("@notes", vol.Notes, ParameterDirection.Input, DbType.String, 500))
            DAL.UpdateData("AddVolunteer", parmList)
            Return True
        End Function

        ''' <summary>
        ''' Gets the volunteers by keyword.
        ''' </summary>
        ''' <param name="keyword">The keyword.</param><returns></returns>
        Public Shared Function getVolunteersByKeyword(keyword As String) As DataTable
            Dim parmList As New List(Of Parm)
            parmList.Add(New Parm("@keyword", keyword, ParameterDirection.Input, DbType.String, 50))
            Return DAL.GetDataTable("getVolunteersByKeyword", parmList)
        End Function

        ''' <summary>
        ''' Gets the partial name of the volunteer by.
        ''' </summary>
        ''' <param name="search">The search.</param><returns></returns>
        Public Shared Function getVolunteerByPartialName(search As String) As DataTable
            Dim parmList As New List(Of Parm)
            parmList.Add(New Parm("@search", search, ParameterDirection.Input, DbType.String, 50))
            Return DAL.GetDataTable("getVolunteersByPartialName", parmList)
        End Function

        ''' <summary>
        ''' Gets the volunteer by topic.
        ''' </summary>
        ''' <param name="topicName">Name of the topic.</param><returns></returns>
        Public Shared Function getVolunteerByTopic(topicName As String) As DataTable
            Dim parmList As New List(Of Parm)
            parmList.Add(New Parm("@topicName", topicName, ParameterDirection.Input, DbType.String, 25))
            Return DAL.GetDataTable("getVolunteersByTopic", parmList)
        End Function

        ''' <summary>
        ''' Modifies the volunteer.
        ''' </summary>
        ''' <param name="vol">The vol.</param><returns></returns>
        Public Shared Function modifyVolunteer(ByVal vol As IVolunteer) As Boolean
            Dim parmList As New List(Of Parm)
            parmList.Add(New Parm("@volunteerID", vol.VolunteerID, ParameterDirection.Input, DbType.Int16))
            parmList.Add(New Parm("@firstname", vol.FirstName, ParameterDirection.Input, DbType.String, 50))
            parmList.Add(New Parm("@lastname", vol.LastName, ParameterDirection.Input, DbType.String, 50))
            parmList.Add(New Parm("@address", vol.Address, ParameterDirection.Input, DbType.String, 50))
            parmList.Add(New Parm("@city", vol.City, ParameterDirection.Input, DbType.String, 50))
            parmList.Add(New Parm("@province", vol.Province, ParameterDirection.Input, DbType.String, 10))
            parmList.Add(New Parm("@postalCode", vol.PostalCode, ParameterDirection.Input, DbType.String, 10))
            parmList.Add(New Parm("@phoneNumber", vol.PhoneNumber, ParameterDirection.Input, DbType.StringFixedLength, 10))
            parmList.Add(New Parm("@email", vol.Email, ParameterDirection.Input, DbType.String, 50))
            parmList.Add(New Parm("@availability", vol.Availability, ParameterDirection.Input, DbType.String, 100))
            parmList.Add(New Parm("@notes", vol.Notes, ParameterDirection.Input, DbType.String, 500))
            DAL.UpdateData("modifyVolunteer", parmList)
            Return True
        End Function

        ''' <summary>
        ''' Adds the volunteer topic.
        ''' </summary>
        ''' <param name="volID">The vol ID.</param>
        ''' <param name="topicid">The topicid.</param><returns></returns>
        Public Shared Function addVolunteerTopic(ByVal volID As Integer, topicid As Integer) As Boolean
            Dim parmlist As New List(Of Parm)
            parmlist.Add(New Parm("@volunteerID", volID, ParameterDirection.Input, DbType.Int32))
            parmlist.Add(New Parm("@topicID", topicid, ParameterDirection.Input, DbType.Int32))
            DAL.UpdateData("addVolunteerTopic", parmlist)
            Return True
        End Function

        ''' <summary>
        ''' Deletes the volunteer topic.
        ''' </summary>
        ''' <param name="volID">The vol ID.</param>
        ''' <param name="topicid">The topicid.</param><returns></returns>
        Public Shared Function deleteVolunteerTopic(ByVal volID As Integer, topicid As Integer) As Boolean
            Dim parmlist As New List(Of Parm)
            parmlist.Add(New Parm("@volunteerID", volID, ParameterDirection.Input, DbType.Int32))
            parmlist.Add(New Parm("@topicID", topicid, ParameterDirection.Input, DbType.Int32))
            DAL.UpdateData("deleteVolunteerTopic", parmlist)
            Return True
        End Function

        Public Shared Function reportVolunteers() As DataTable
            Return DAL.GetDataTable("reportAllVolunteerAndInfo")
        End Function

        Public Shared Function reportActiveVolunteers() As DataTable
            Return DAL.GetDataTable("reportAllVolunteersFromYear")
        End Function

    End Class

End Namespace