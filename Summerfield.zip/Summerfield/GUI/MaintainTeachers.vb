﻿Option Strict On

Imports Summerfield.BOL
Imports Summerfield.Utilities


Public Class frmMaintainTeachers

    ''' <summary>
    ''' Handles the Load event of the MaintainTeachers control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub MaintainTeachers_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Try
            'Load form defaults
            setupForm()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try


    End Sub

    ''' <summary>
    ''' Setups the form.
    ''' </summary>
    Private Sub setupForm()

        btnSave.Enabled = False
        dgvBookingHistory.Enabled = False
        btnSave.Enabled = False
        btnEdit.Enabled = True
        chkAdmin.Enabled = False
        lstTeacher.Enabled = True
        btnAdd.Enabled = True
        btnDelete.Enabled = True

        For Each ctl As Control In grpContactInfo.Controls
            If TypeOf ctl Is TextBox Then
                Dim t As TextBox = DirectCast(ctl, TextBox)
                t.ReadOnly = True
            End If
        Next

        'Loads the teachers listbox with the default result set
        loadTeachers()


    End Sub

    ''' <summary>
    ''' Loads the teachers.
    ''' </summary>
    Private Sub loadTeachers()

        Dim teachers As List(Of TeacherLists) = TeacherLists.RetrieveTeacherList(RetrieveType.LookupTable)

        lstTeacher.DataSource = teachers
        lstTeacher.DisplayMember = "FullName"
        lstTeacher.ValueMember = "TeacherID"

    End Sub

    ''' <summary>
    ''' Loads the bookings.
    ''' </summary>
    ''' <param name="volID">The vol ID.</param>
    Private Sub loadBookings(volID As Integer)
        Try
            Dim xBooking As List(Of BookingLists) = BookingLists.getVolunteerBookings(volID)
            Dim BookingBindingSource As New BindingSource
            BookingBindingSource.DataSource = xBooking
            dgvBookingHistory.DataSource = BookingBindingSource
            dgvBookingHistory.Columns("VolunteerID").Visible = False
            dgvBookingHistory.Columns("BookingID").Visible = False
        Catch ex As Exception
            dgvBookingHistory.DataSource = Nothing
            dgvBookingHistory.Rows.Clear()

        End Try

    End Sub

    ''' <summary>
    ''' Handles the ValueMemberChanged event of the lstTeacher control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub lstTeacher_ValueMemberChanged(sender As Object, e As System.EventArgs) Handles lstTeacher.ValueMemberChanged, lstTeacher.Click
        Dim t As Teacher = Teacher.Create(Convert.ToInt16(lstTeacher.SelectedValue))
        txtFirstName.Text = t.firstName
        txtLastName.Text = t.lastName
        txtEmail.Text = t.email
        txtPhone.Text = t.phoneNumber.Substring(0, 3) + "-" + t.phoneNumber.Substring(3, 3) + "-" + t.phoneNumber.Substring(6)
        txtPassword.Text = t.password
        chkAdmin.Checked = t.admin
        loadBookings(Convert.ToInt16(lstTeacher.SelectedValue))

    End Sub

    ''' <summary>
    ''' Handles the Click event of the btnEdit control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub btnEdit_Click(sender As System.Object, e As System.EventArgs) Handles btnEdit.Click
        btnSave.Enabled = True
        btnEdit.Enabled = False
        btnAdd.Enabled = False
        chkAdmin.Enabled = True
        lstTeacher.Enabled = False

        For Each ctl As Control In grpContactInfo.Controls
            If TypeOf ctl Is TextBox Then
                Dim t As TextBox = DirectCast(ctl, TextBox)
                t.ReadOnly = False
            End If
        Next

    End Sub

    ''' <summary>
    ''' Handles the Update event of the Insert control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub Insert_Update(sender As System.Object, e As System.EventArgs) Handles btnSave.Click
        Try
            If btnSave.Text = "SAVE CHANGES" Then
                UpdateTeacher()
                Dim bookmark As Integer = lstTeacher.SelectedIndex
                setupForm()
                lstTeacher.SelectedIndex = bookmark
            Else
                InsertTeacher()

            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    ''' <summary>
    ''' Parses the phone.
    ''' </summary>
    ''' <param name="phone">The phone.</param><returns></returns>
    Private Function parsePhone(phone As String) As String

        Return phone.Substring(0, 3) + phone.Substring(4, 3) + phone.Substring(8)

    End Function

    ''' <summary>
    ''' Handles the Click event of the btnAdd control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub btnAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnAdd.Click
        If btnAdd.Text = "ADD" Then
            grpContactInfo.Enabled = True
            chkAdmin.Enabled = True
            btnSave.Text = "INSERT TEACHER"
            btnAdd.Enabled = False
            btnSave.Enabled = True
            btnEdit.Enabled = False
            btnDelete.Enabled = False
            lstTeacher.Enabled = False
            lstTeacher.SelectedIndex = -1
            dgvBookingHistory.DataSource = Nothing

            For Each ctl As Control In grpContactInfo.Controls
                If TypeOf ctl Is TextBox Then
                    Dim t As TextBox = DirectCast(ctl, TextBox)
                    t.ReadOnly = False
                    t.Clear()
                End If
            Next

            chkAdmin.Checked = False
            txtFirstName.Focus()

        End If
    End Sub

    ''' <summary>
    ''' Handles the Click event of the btnDelete control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub btnDelete_Click(sender As System.Object, e As System.EventArgs) Handles btnDelete.Click
        Try
            TeacherCUD.Delete(Convert.ToInt16(lstTeacher.SelectedValue))
            setupForm()
            lstTeacher_ValueMemberChanged(Nothing, Nothing)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    ''' <summary>
    ''' Updates the teacher.
    ''' </summary>
    Private Sub UpdateTeacher()
        Try

            Dim teacher As Teacher = teacher.Create()
            teacher.firstName = txtFirstName.Text.Trim()
            teacher.lastName = txtLastName.Text.Trim()
            teacher.phoneNumber = parsePhone(txtPhone.Text)
            teacher.email = txtEmail.Text.Trim()
            teacher.password = txtPassword.Text
            teacher.admin = chkAdmin.Checked
            teacher.teacherID = Convert.ToInt16(lstTeacher.SelectedValue)

            TeacherCUD.Update(teacher)

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    ''' <summary>
    ''' Inserts the teacher.
    ''' </summary>
    Private Sub InsertTeacher()
        Try
            Dim teacher As Teacher = teacher.Create()
            teacher.firstName = txtFirstName.Text.Trim()
            teacher.lastName = txtLastName.Text.Trim()
            teacher.phoneNumber = parsePhone(txtPhone.Text)
            teacher.email = txtEmail.Text.Trim()
            teacher.password = txtPassword.Text
            teacher.admin = chkAdmin.Checked

            TeacherCUD.Insert(teacher)
            setupForm()

            lstTeacher.SelectedValue = teacher.teacherID
            btnSave.Text = "SAVE CHANGES"

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

#Region "Search"

    ''' <summary>
    ''' Handles the Click event of the txtSearch control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub txtSearch_Click(sender As Object, e As System.EventArgs) Handles txtSearch.Click
        txtSearch.SelectAll()
    End Sub

    ''' <summary>
    ''' Handles the Click event of the btnSearch control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub btnSearch_Click(sender As System.Object, e As System.EventArgs) Handles btnSearch.Click

        Dim teachers As List(Of TeacherLists) = TeacherLists.RetrieveTeacherList(RetrieveType.LookupTable)

        lstTeacher.DataSource = Search(teachers, txtSearch.Text)
        lstTeacher.DisplayMember = "FullName"
        lstTeacher.ValueMember = "TeacherID"

    End Sub

    ''' <summary>
    ''' Searches the specified list.
    ''' </summary>
    ''' <param name="lst">The LST.</param>
    ''' <param name="strSearch">The STR search.</param><returns></returns>
    Private Function Search(ByVal lst As List(Of TeacherLists), strSearch As String) As List(Of TeacherLists)

        'Creates a new list to hold the results
        Dim lstSearchResult As List(Of TeacherLists) = New List(Of TeacherLists)

        'Loop through the list passed in and see if it contains the search string
        For Each item As TeacherLists In lst
            'modify this for what you want to search in
            If item.FullName.ToUpper.Contains(strSearch.ToUpper) Then
                lstSearchResult.Add(item)
            End If
        Next

        Return lstSearchResult

    End Function

#End Region




    
End Class

