﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(main))
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.mmuFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mmuNew = New System.Windows.Forms.ToolStripMenuItem()
        Me.mmuOpen = New System.Windows.Forms.ToolStripMenuItem()
        Me.toolStripSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.mmuSave = New System.Windows.Forms.ToolStripMenuItem()
        Me.mmuSaveAs = New System.Windows.Forms.ToolStripMenuItem()
        Me.toolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.mmuPrint = New System.Windows.Forms.ToolStripMenuItem()
        Me.mmuPrintPreview = New System.Windows.Forms.ToolStripMenuItem()
        Me.toolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.mmuExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.mmuAdmin = New System.Windows.Forms.ToolStripMenuItem()
        Me.mmuReports = New System.Windows.Forms.ToolStripMenuItem()
        Me.mmuHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.mmuContents = New System.Windows.Forms.ToolStripMenuItem()
        Me.mmuIndex = New System.Windows.Forms.ToolStripMenuItem()
        Me.mmuSearch = New System.Windows.Forms.ToolStripMenuItem()
        Me.toolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.mmuAbout = New System.Windows.Forms.ToolStripMenuItem()
        Me.TabControl1 = New MdiTabControl.TabControl()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblReports = New System.Windows.Forms.Label()
        Me.lblMTopic = New System.Windows.Forms.Label()
        Me.lblMTeacher = New System.Windows.Forms.Label()
        Me.lblMVolunteer = New System.Windows.Forms.Label()
        Me.lblMBooking = New System.Windows.Forms.Label()
        Me.lblBBookings = New System.Windows.Forms.Label()
        Me.lblBVolunteers = New System.Windows.Forms.Label()
        Me.lblMaintenance = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.StatusStrip1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.SuspendLayout()
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel2, Me.ToolStripStatusLabel3})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 687)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1362, 22)
        Me.StatusStrip1.TabIndex = 0
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(121, 17)
        Me.ToolStripStatusLabel1.Text = "ToolStripStatusLabel1"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(1105, 17)
        Me.ToolStripStatusLabel2.Spring = True
        Me.ToolStripStatusLabel2.Text = "ToolStripStatusLabel2"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(121, 17)
        Me.ToolStripStatusLabel3.Text = "ToolStripStatusLabel3"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mmuFile, Me.mmuAdmin, Me.mmuReports, Me.mmuHelp})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1362, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'mmuFile
        '
        Me.mmuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mmuNew, Me.mmuOpen, Me.toolStripSeparator, Me.mmuSave, Me.mmuSaveAs, Me.toolStripSeparator1, Me.mmuPrint, Me.mmuPrintPreview, Me.toolStripSeparator2, Me.mmuExit})
        Me.mmuFile.Name = "mmuFile"
        Me.mmuFile.Size = New System.Drawing.Size(37, 20)
        Me.mmuFile.Text = "&File"
        '
        'mmuNew
        '
        Me.mmuNew.Image = CType(resources.GetObject("mmuNew.Image"), System.Drawing.Image)
        Me.mmuNew.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.mmuNew.Name = "mmuNew"
        Me.mmuNew.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.mmuNew.Size = New System.Drawing.Size(146, 22)
        Me.mmuNew.Text = "&New"
        '
        'mmuOpen
        '
        Me.mmuOpen.Image = CType(resources.GetObject("mmuOpen.Image"), System.Drawing.Image)
        Me.mmuOpen.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.mmuOpen.Name = "mmuOpen"
        Me.mmuOpen.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.mmuOpen.Size = New System.Drawing.Size(146, 22)
        Me.mmuOpen.Text = "&Open"
        '
        'toolStripSeparator
        '
        Me.toolStripSeparator.Name = "toolStripSeparator"
        Me.toolStripSeparator.Size = New System.Drawing.Size(143, 6)
        '
        'mmuSave
        '
        Me.mmuSave.Image = CType(resources.GetObject("mmuSave.Image"), System.Drawing.Image)
        Me.mmuSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.mmuSave.Name = "mmuSave"
        Me.mmuSave.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.mmuSave.Size = New System.Drawing.Size(146, 22)
        Me.mmuSave.Text = "&Save"
        '
        'mmuSaveAs
        '
        Me.mmuSaveAs.Name = "mmuSaveAs"
        Me.mmuSaveAs.Size = New System.Drawing.Size(146, 22)
        Me.mmuSaveAs.Text = "Save &As"
        '
        'toolStripSeparator1
        '
        Me.toolStripSeparator1.Name = "toolStripSeparator1"
        Me.toolStripSeparator1.Size = New System.Drawing.Size(143, 6)
        '
        'mmuPrint
        '
        Me.mmuPrint.Image = CType(resources.GetObject("mmuPrint.Image"), System.Drawing.Image)
        Me.mmuPrint.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.mmuPrint.Name = "mmuPrint"
        Me.mmuPrint.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.P), System.Windows.Forms.Keys)
        Me.mmuPrint.Size = New System.Drawing.Size(146, 22)
        Me.mmuPrint.Text = "&Print"
        '
        'mmuPrintPreview
        '
        Me.mmuPrintPreview.Image = CType(resources.GetObject("mmuPrintPreview.Image"), System.Drawing.Image)
        Me.mmuPrintPreview.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.mmuPrintPreview.Name = "mmuPrintPreview"
        Me.mmuPrintPreview.Size = New System.Drawing.Size(146, 22)
        Me.mmuPrintPreview.Text = "Print Pre&view"
        '
        'toolStripSeparator2
        '
        Me.toolStripSeparator2.Name = "toolStripSeparator2"
        Me.toolStripSeparator2.Size = New System.Drawing.Size(143, 6)
        '
        'mmuExit
        '
        Me.mmuExit.Name = "mmuExit"
        Me.mmuExit.Size = New System.Drawing.Size(146, 22)
        Me.mmuExit.Text = "E&xit"
        '
        'mmuAdmin
        '
        Me.mmuAdmin.Name = "mmuAdmin"
        Me.mmuAdmin.Size = New System.Drawing.Size(55, 20)
        Me.mmuAdmin.Text = "Admin"
        '
        'mmuReports
        '
        Me.mmuReports.Name = "mmuReports"
        Me.mmuReports.Size = New System.Drawing.Size(59, 20)
        Me.mmuReports.Text = "Reports"
        '
        'mmuHelp
        '
        Me.mmuHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mmuContents, Me.mmuIndex, Me.mmuSearch, Me.toolStripSeparator5, Me.mmuAbout})
        Me.mmuHelp.Name = "mmuHelp"
        Me.mmuHelp.Size = New System.Drawing.Size(44, 20)
        Me.mmuHelp.Text = "&Help"
        '
        'mmuContents
        '
        Me.mmuContents.Name = "mmuContents"
        Me.mmuContents.Size = New System.Drawing.Size(122, 22)
        Me.mmuContents.Text = "&Contents"
        '
        'mmuIndex
        '
        Me.mmuIndex.Name = "mmuIndex"
        Me.mmuIndex.Size = New System.Drawing.Size(122, 22)
        Me.mmuIndex.Text = "&Index"
        '
        'mmuSearch
        '
        Me.mmuSearch.Name = "mmuSearch"
        Me.mmuSearch.Size = New System.Drawing.Size(122, 22)
        Me.mmuSearch.Text = "&Search"
        '
        'toolStripSeparator5
        '
        Me.toolStripSeparator5.Name = "toolStripSeparator5"
        Me.toolStripSeparator5.Size = New System.Drawing.Size(119, 6)
        '
        'mmuAbout
        '
        Me.mmuAbout.Name = "mmuAbout"
        Me.mmuAbout.Size = New System.Drawing.Size(122, 22)
        Me.mmuAbout.Text = "&About..."
        '
        'TabControl1
        '
        Me.TabControl1.Alignment = MdiTabControl.TabControl.TabAlignment.Top
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.MenuRenderer = Nothing
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.Size = New System.Drawing.Size(1130, 663)
        Me.TabControl1.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.None
        Me.TabControl1.TabBorderEnhanceWeight = MdiTabControl.TabControl.Weight.Medium
        Me.TabControl1.TabCloseButtonImage = Nothing
        Me.TabControl1.TabCloseButtonImageDisabled = Nothing
        Me.TabControl1.TabCloseButtonImageHot = Nothing
        Me.TabControl1.TabIndex = 3
        Me.TabControl1.TabsDirection = MdiTabControl.TabControl.FlowDirection.LeftToRight
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.White
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(225, 177)
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'lblReports
        '
        Me.lblReports.AutoSize = True
        Me.lblReports.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblReports.ForeColor = System.Drawing.Color.Black
        Me.lblReports.Location = New System.Drawing.Point(64, 436)
        Me.lblReports.Name = "lblReports"
        Me.lblReports.Size = New System.Drawing.Size(56, 16)
        Me.lblReports.TabIndex = 10
        Me.lblReports.Text = "Reports"
        '
        'lblMTopic
        '
        Me.lblMTopic.AutoSize = True
        Me.lblMTopic.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMTopic.ForeColor = System.Drawing.Color.Black
        Me.lblMTopic.Location = New System.Drawing.Point(64, 409)
        Me.lblMTopic.Name = "lblMTopic"
        Me.lblMTopic.Size = New System.Drawing.Size(50, 16)
        Me.lblMTopic.TabIndex = 9
        Me.lblMTopic.Text = "Topics"
        '
        'lblMTeacher
        '
        Me.lblMTeacher.AutoSize = True
        Me.lblMTeacher.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMTeacher.ForeColor = System.Drawing.Color.Black
        Me.lblMTeacher.Location = New System.Drawing.Point(64, 382)
        Me.lblMTeacher.Name = "lblMTeacher"
        Me.lblMTeacher.Size = New System.Drawing.Size(66, 16)
        Me.lblMTeacher.TabIndex = 8
        Me.lblMTeacher.Text = "Teachers"
        '
        'lblMVolunteer
        '
        Me.lblMVolunteer.AutoSize = True
        Me.lblMVolunteer.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMVolunteer.ForeColor = System.Drawing.Color.Black
        Me.lblMVolunteer.Location = New System.Drawing.Point(64, 355)
        Me.lblMVolunteer.Name = "lblMVolunteer"
        Me.lblMVolunteer.Size = New System.Drawing.Size(72, 16)
        Me.lblMVolunteer.TabIndex = 7
        Me.lblMVolunteer.Text = "Volunteers"
        '
        'lblMBooking
        '
        Me.lblMBooking.AutoSize = True
        Me.lblMBooking.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMBooking.ForeColor = System.Drawing.Color.Black
        Me.lblMBooking.Location = New System.Drawing.Point(64, 328)
        Me.lblMBooking.Name = "lblMBooking"
        Me.lblMBooking.Size = New System.Drawing.Size(119, 16)
        Me.lblMBooking.TabIndex = 6
        Me.lblMBooking.Text = "Change a Booking"
        '
        'lblBBookings
        '
        Me.lblBBookings.AutoSize = True
        Me.lblBBookings.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBBookings.ForeColor = System.Drawing.Color.Black
        Me.lblBBookings.Location = New System.Drawing.Point(64, 239)
        Me.lblBBookings.Name = "lblBBookings"
        Me.lblBBookings.Size = New System.Drawing.Size(113, 16)
        Me.lblBBookings.TabIndex = 4
        Me.lblBBookings.Text = "Browse Bookings"
        '
        'lblBVolunteers
        '
        Me.lblBVolunteers.AutoSize = True
        Me.lblBVolunteers.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBVolunteers.ForeColor = System.Drawing.Color.Black
        Me.lblBVolunteers.Location = New System.Drawing.Point(64, 266)
        Me.lblBVolunteers.Name = "lblBVolunteers"
        Me.lblBVolunteers.Size = New System.Drawing.Size(120, 16)
        Me.lblBVolunteers.TabIndex = 3
        Me.lblBVolunteers.Text = "Browse Volunteers"
        '
        'lblMaintenance
        '
        Me.lblMaintenance.AutoSize = True
        Me.lblMaintenance.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMaintenance.ForeColor = System.Drawing.Color.Blue
        Me.lblMaintenance.Location = New System.Drawing.Point(28, 297)
        Me.lblMaintenance.Name = "lblMaintenance"
        Me.lblMaintenance.Size = New System.Drawing.Size(101, 20)
        Me.lblMaintenance.TabIndex = 1
        Me.lblMaintenance.Text = "Maintenance"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Blue
        Me.Label1.Location = New System.Drawing.Point(28, 207)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(62, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Browse"
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.IsSplitterFixed = True
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 24)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.PictureBox1)
        Me.SplitContainer1.Panel1.Controls.Add(Me.lblReports)
        Me.SplitContainer1.Panel1.Controls.Add(Me.lblMaintenance)
        Me.SplitContainer1.Panel1.Controls.Add(Me.lblMTopic)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Label1)
        Me.SplitContainer1.Panel1.Controls.Add(Me.lblMTeacher)
        Me.SplitContainer1.Panel1.Controls.Add(Me.lblBVolunteers)
        Me.SplitContainer1.Panel1.Controls.Add(Me.lblMVolunteer)
        Me.SplitContainer1.Panel1.Controls.Add(Me.lblBBookings)
        Me.SplitContainer1.Panel1.Controls.Add(Me.lblMBooking)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.TabControl1)
        Me.SplitContainer1.Size = New System.Drawing.Size(1362, 663)
        Me.SplitContainer1.SplitterDistance = 228
        Me.SplitContainer1.TabIndex = 7
        '
        'main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1362, 709)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "main"
        Me.Text = "main"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel1.PerformLayout()
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents mmuFile As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mmuNew As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mmuOpen As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mmuSave As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mmuSaveAs As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mmuPrint As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mmuPrintPreview As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mmuExit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mmuHelp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mmuContents As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mmuIndex As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mmuSearch As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mmuAbout As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mmuAdmin As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mmuReports As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents TabControl1 As MdiTabControl.TabControl
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents lblReports As System.Windows.Forms.Label
    Friend WithEvents lblMTopic As System.Windows.Forms.Label
    Friend WithEvents lblMTeacher As System.Windows.Forms.Label
    Friend WithEvents lblMVolunteer As System.Windows.Forms.Label
    Friend WithEvents lblMBooking As System.Windows.Forms.Label
    Friend WithEvents lblBBookings As System.Windows.Forms.Label
    Friend WithEvents lblBVolunteers As System.Windows.Forms.Label
    Friend WithEvents lblMaintenance As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
End Class
