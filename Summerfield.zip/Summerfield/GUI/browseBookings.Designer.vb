﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class browseBookings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.grpDate = New System.Windows.Forms.GroupBox()
        Me.btnSDate = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.dtpMax = New System.Windows.Forms.DateTimePicker()
        Me.dtpMin = New System.Windows.Forms.DateTimePicker()
        Me.grpVolunteer = New System.Windows.Forms.GroupBox()
        Me.btnSVol = New System.Windows.Forms.Button()
        Me.txtVolName = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.grpTeacher = New System.Windows.Forms.GroupBox()
        Me.btnSTeach = New System.Windows.Forms.Button()
        Me.txtTeachName = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.dgvBookings = New System.Windows.Forms.DataGridView()
        Me.lblMessage = New System.Windows.Forms.Label()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.grpDate.SuspendLayout()
        Me.grpVolunteer.SuspendLayout()
        Me.grpTeacher.SuspendLayout()
        CType(Me.dgvBookings, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(26, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(186, 24)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Browse Bookings by:"
        '
        'grpDate
        '
        Me.grpDate.Controls.Add(Me.btnSDate)
        Me.grpDate.Controls.Add(Me.Label3)
        Me.grpDate.Controls.Add(Me.Label2)
        Me.grpDate.Controls.Add(Me.dtpMax)
        Me.grpDate.Controls.Add(Me.dtpMin)
        Me.grpDate.Location = New System.Drawing.Point(51, 78)
        Me.grpDate.Name = "grpDate"
        Me.grpDate.Size = New System.Drawing.Size(282, 124)
        Me.grpDate.TabIndex = 1
        Me.grpDate.TabStop = False
        Me.grpDate.Text = "Date"
        '
        'btnSDate
        '
        Me.btnSDate.Location = New System.Drawing.Point(102, 82)
        Me.btnSDate.Name = "btnSDate"
        Me.btnSDate.Size = New System.Drawing.Size(75, 23)
        Me.btnSDate.TabIndex = 7
        Me.btnSDate.Text = "Search"
        Me.btnSDate.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(36, 47)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(25, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "and"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 24)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(49, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Between"
        '
        'dtpMax
        '
        Me.dtpMax.Location = New System.Drawing.Point(67, 47)
        Me.dtpMax.Name = "dtpMax"
        Me.dtpMax.Size = New System.Drawing.Size(200, 20)
        Me.dtpMax.TabIndex = 3
        '
        'dtpMin
        '
        Me.dtpMin.Location = New System.Drawing.Point(67, 24)
        Me.dtpMin.Name = "dtpMin"
        Me.dtpMin.Size = New System.Drawing.Size(200, 20)
        Me.dtpMin.TabIndex = 2
        '
        'grpVolunteer
        '
        Me.grpVolunteer.Controls.Add(Me.btnSVol)
        Me.grpVolunteer.Controls.Add(Me.txtVolName)
        Me.grpVolunteer.Controls.Add(Me.Label4)
        Me.grpVolunteer.Location = New System.Drawing.Point(427, 78)
        Me.grpVolunteer.Name = "grpVolunteer"
        Me.grpVolunteer.Size = New System.Drawing.Size(282, 124)
        Me.grpVolunteer.TabIndex = 6
        Me.grpVolunteer.TabStop = False
        Me.grpVolunteer.Text = "Volunteer Name"
        '
        'btnSVol
        '
        Me.btnSVol.Location = New System.Drawing.Point(102, 82)
        Me.btnSVol.Name = "btnSVol"
        Me.btnSVol.Size = New System.Drawing.Size(75, 23)
        Me.btnSVol.TabIndex = 8
        Me.btnSVol.Text = "Search"
        Me.btnSVol.UseVisualStyleBackColor = True
        '
        'txtVolName
        '
        Me.txtVolName.Location = New System.Drawing.Point(75, 28)
        Me.txtVolName.Name = "txtVolName"
        Me.txtVolName.Size = New System.Drawing.Size(190, 20)
        Me.txtVolName.TabIndex = 1
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 31)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(63, 13)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Enter Name"
        '
        'grpTeacher
        '
        Me.grpTeacher.Controls.Add(Me.btnSTeach)
        Me.grpTeacher.Controls.Add(Me.txtTeachName)
        Me.grpTeacher.Controls.Add(Me.Label5)
        Me.grpTeacher.Location = New System.Drawing.Point(797, 78)
        Me.grpTeacher.Name = "grpTeacher"
        Me.grpTeacher.Size = New System.Drawing.Size(282, 124)
        Me.grpTeacher.TabIndex = 6
        Me.grpTeacher.TabStop = False
        Me.grpTeacher.Text = "Teacher Name"
        '
        'btnSTeach
        '
        Me.btnSTeach.Location = New System.Drawing.Point(115, 82)
        Me.btnSTeach.Name = "btnSTeach"
        Me.btnSTeach.Size = New System.Drawing.Size(75, 23)
        Me.btnSTeach.TabIndex = 9
        Me.btnSTeach.Text = "Search"
        Me.btnSTeach.UseVisualStyleBackColor = True
        '
        'txtTeachName
        '
        Me.txtTeachName.Location = New System.Drawing.Point(85, 28)
        Me.txtTeachName.Name = "txtTeachName"
        Me.txtTeachName.Size = New System.Drawing.Size(190, 20)
        Me.txtTeachName.TabIndex = 3
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(16, 31)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(63, 13)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Enter Name"
        '
        'dgvBookings
        '
        Me.dgvBookings.AllowUserToAddRows = False
        Me.dgvBookings.AllowUserToDeleteRows = False
        Me.dgvBookings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvBookings.Location = New System.Drawing.Point(30, 237)
        Me.dgvBookings.Name = "dgvBookings"
        Me.dgvBookings.Size = New System.Drawing.Size(1076, 305)
        Me.dgvBookings.TabIndex = 7
        '
        'lblMessage
        '
        Me.lblMessage.AutoSize = True
        Me.lblMessage.ForeColor = System.Drawing.Color.Red
        Me.lblMessage.Location = New System.Drawing.Point(502, 209)
        Me.lblMessage.Name = "lblMessage"
        Me.lblMessage.Size = New System.Drawing.Size(0, 13)
        Me.lblMessage.TabIndex = 8
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(519, 548)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(94, 23)
        Me.btnSave.TabIndex = 9
        Me.btnSave.Text = "Save Changes"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'browseBookings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1136, 591)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.lblMessage)
        Me.Controls.Add(Me.dgvBookings)
        Me.Controls.Add(Me.grpTeacher)
        Me.Controls.Add(Me.grpVolunteer)
        Me.Controls.Add(Me.grpDate)
        Me.Controls.Add(Me.Label1)
        Me.Name = "browseBookings"
        Me.Text = "browseBookings"
        Me.grpDate.ResumeLayout(False)
        Me.grpDate.PerformLayout()
        Me.grpVolunteer.ResumeLayout(False)
        Me.grpVolunteer.PerformLayout()
        Me.grpTeacher.ResumeLayout(False)
        Me.grpTeacher.PerformLayout()
        CType(Me.dgvBookings, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents grpDate As System.Windows.Forms.GroupBox
    Friend WithEvents btnSDate As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents dtpMax As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpMin As System.Windows.Forms.DateTimePicker
    Friend WithEvents grpVolunteer As System.Windows.Forms.GroupBox
    Friend WithEvents btnSVol As System.Windows.Forms.Button
    Friend WithEvents txtVolName As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents grpTeacher As System.Windows.Forms.GroupBox
    Friend WithEvents btnSTeach As System.Windows.Forms.Button
    Friend WithEvents txtTeachName As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents dgvBookings As System.Windows.Forms.DataGridView
    Friend WithEvents lblMessage As System.Windows.Forms.Label
    Friend WithEvents btnSave As System.Windows.Forms.Button
End Class
