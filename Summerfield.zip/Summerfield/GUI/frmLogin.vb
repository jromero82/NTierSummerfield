﻿Option Strict On

Imports Summerfield.BOL

Public Class frmLogin

    ''' <summary>
    ''' Handles the Click event of the btnLogin control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub btnLogin_Click(sender As System.Object, e As System.EventArgs) Handles btnLogin.Click
        CheckLogin()
    End Sub

    ''' <summary>
    ''' Checks the login.
    ''' </summary>
    Private Sub CheckLogin()
        Dim lstResults As ArrayList = Login.checkLogin(txtUsername.Text, txtPassword.Text)

        If CInt(lstResults.Item(0)) = 0 Then
            lblMessage.Visible = True
            txtPassword.ResetText()
            txtUsername.SelectAll()
            txtUsername.Focus()
        ElseIf CInt(lstResults.Item(0)) = 1 Then
            My.Settings.TeacherID = CInt(lstResults.Item(1))
            My.Settings.admin = False
            main.ShowDialog()
            Me.Close()
        ElseIf CInt(lstResults.Item(0)) = 2 Then
            My.Settings.TeacherID = CInt(lstResults.Item(1))
            My.Settings.admin = True
            main.ShowDialog()
            Me.Close()
        End If


    End Sub

    ''' <summary>
    ''' Handles the click event of the txtUsername control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub txtUsername_click(sender As System.Object, e As System.EventArgs) Handles txtUsername.Click
        lblMessage.Visible = False
    End Sub

    ''' <summary>
    ''' Handles the click event of the txtPassword control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub txtPassword_click(sender As System.Object, e As System.EventArgs) Handles txtPassword.Click
        lblMessage.Visible = False
    End Sub

    ''' <summary>
    ''' Handles the Load event of the frmLogin control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub frmLogin_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class