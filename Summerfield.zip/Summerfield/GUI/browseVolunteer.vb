﻿Option Strict On
Imports Summerfield.BOL
Imports Summerfield.Utilities

Public Class frmBrowseVolunteer


    Private Search As String
    Private loading As Boolean

#Region "Form Load"

    ''' <summary>
    ''' Handles the Load event of the frmModifyVolunteer control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub frmModifyVolunteer_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        grpBooking.Visible = False
        btnCreate.Visible = False
        fillProvinces()
        fillVolunteerList()
        fillTopicDropDown()

    End Sub

    ''' <summary>
    ''' Fills the volunteer list.
    ''' </summary>
    Private Sub fillVolunteerList()
        loading = True
        Try
            Dim xVol As List(Of VolunteerList) = VolunteerList.VolunteerLookup()

            lstVolunteers.DataSource = xVol
            lstVolunteers.DisplayMember = "FullName"
            lstVolunteers.ValueMember = "VolunteerID"

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        loading = False

    End Sub

    ''' <summary>
    ''' Fills the topic list.
    ''' </summary>
    ''' <param name="volID">The vol ID.</param>
    Private Sub fillTopicList(volID As Integer)
        Try
            Dim xTopic As List(Of Topic) = Topic.getVolunteerTopic(volID)

            lstTopic.DataSource = xTopic
            lstTopic.DisplayMember = "topicName"
            lstTopic.ValueMember = "topicID"

        Catch ex As Exception
            lstTopic.DataSource = Nothing
            lstTopic.Items.Clear()
            MessageBox.Show(ex.Message)

        End Try

    End Sub



    ''' <summary>
    ''' Fills the provinces.
    ''' </summary>
    Private Sub fillProvinces()
        ddlProv.Items.Add("Alberta")
        ddlProv.Items.Add("British Columbia")
        ddlProv.Items.Add("Manitoba")
        ddlProv.Items.Add("New Brunswick")
        ddlProv.Items.Add("Newfoundland and Labrador")
        ddlProv.Items.Add("Northwest Territories")
        ddlProv.Items.Add("Nova Scotia")
        ddlProv.Items.Add("Nunavut")
        ddlProv.Items.Add("Ontario")
        ddlProv.Items.Add("Prince Edward Island")
        ddlProv.Items.Add("Quebec")
        ddlProv.Items.Add("Saskatchewan")
        ddlProv.Items.Add("Yukon")

    End Sub

    ''' <summary>
    ''' Fills the topic drop down.
    ''' </summary>
    Private Sub fillTopicDropDown()
        Try
            Dim xTopic As List(Of Topic) = Topic.TopicLookup()
            ddlTopics.DataSource = xTopic
            ddlTopics.DisplayMember = "topicName"
            ddlTopics.ValueMember = "topicID"
            cmbTopics.DataSource = xTopic
            cmbTopics.DisplayMember = "topicName"
            cmbTopics.ValueMember = "topicID"
            cmbTopics.Enabled = False
            btnAddTopic.Enabled = False
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

#End Region

#Region "Get Volunteer Details"

    ''' <summary>
    ''' Gets the volunteer details.
    ''' </summary>
    ''' <param name="VolID">The vol ID.</param>
    Private Sub getVolunteerDetails(VolID As Integer)
        Dim xVol As Volunteer
        xVol = Volunteer.Create(VolID)
        txtfName.Text = xVol.firstName
        txtlName.Text = xVol.lastName
        txtPhone.Text = xVol.phoneNumber
        txtEmail.Text = xVol.email
        txtStreet.Text = xVol.address
        txtCity.Text = xVol.city
        txtPostal.Text = xVol.postalCode
        ddlProv.SelectedItem = xVol.province
        txtAvail.Text = xVol.availability
        txtDesc.Text = xVol.notes
        getBookings(CInt(lstVolunteers.SelectedValue))
        fillTopicList(VolID)
    End Sub

    ''' <summary>
    ''' Gets the bookings.
    ''' </summary>
    ''' <param name="volID">The vol ID.</param>
    Public Sub getBookings(volID As Integer)
        If loading = False Then
            Try
                Dim xBooking As List(Of BookingLists) = BookingLists.getVolunteerBookings(volID)
                Dim BookingBindingSource As New BindingSource
                BookingBindingSource.DataSource = xBooking
                dgvBookings.DataSource = BookingBindingSource
                dgvBookings.Columns("VolunteerID").Visible = False
                dgvBookings.Columns("BookingID").Visible = False
                dgvBookings.Columns("TopicID").Visible = False
            Catch ex As Exception
                dgvBookings.DataSource = Nothing
                dgvBookings.Rows.Clear()
            End Try
        Else
            Exit Sub
        End If


    End Sub

    ''' <summary>
    ''' Handles the SelectedIndexChanged event of the lstVolunteers control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub lstVolunteers_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles lstVolunteers.Click
        If loading = False Then
            If Not lstVolunteers.SelectedIndex = -1 Then
                getVolunteerDetails(Convert.ToInt32(lstVolunteers.SelectedValue))
                fillTopicdd(CInt(lstVolunteers.SelectedValue))
            End If
        Else
            Return
        End If
    End Sub

#End Region

#Region "Search"

    ''' <summary>
    ''' Handles the Click event of the btnSearch control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub btnSearch_Click(sender As System.Object, e As System.EventArgs) Handles btnSearch.Click
        SearchVolunteers()
    End Sub

    ''' <summary>
    ''' Handles the CheckedChanged event of the rdo control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub rdo_CheckedChanged(sender As System.Object, e As System.EventArgs) _
        Handles rdoKeyword.CheckedChanged, rdoName.CheckedChanged, rdoTopic.CheckedChanged

        Select Case True
            Case rdoKeyword.Checked
                txtKeyword.Enabled = True
                txtName.Enabled = False
                ddlTopics.Enabled = False
                rdoName.Checked = False
                rdoTopic.Checked = False
                Search = "Keyword"
            Case rdoName.Checked
                txtKeyword.Enabled = False
                txtName.Enabled = True
                ddlTopics.Enabled = False
                rdoTopic.Checked = False
                Search = "Name"
            Case rdoTopic.Checked
                txtKeyword.Enabled = False
                txtName.Enabled = False
                ddlTopics.Enabled = True
                rdoName.Checked = False
                Search = "Topic"
        End Select
        fillVolunteerList()
        clearForm()

        For Each ctl As Control In SplitContainer1.Panel1.Controls
            If TypeOf ctl Is GroupBox Then
                For Each ctlx As Control In ctl.Controls
                    If TypeOf ctlx Is TextBox OrElse
                        TypeOf ctlx Is ComboBox Then

                        ctlx.ResetText()

                    End If
                Next
            End If
        Next

    End Sub

    ''' <summary>
    ''' Searches the volunteers.
    ''' </summary>
    Private Sub SearchVolunteers()
        Try
            If Search = "Keyword" Then
                Dim xVol As List(Of VolunteerList) = VolunteerList.Search(txtKeyword.Text, SearchParm.SearchByKeyword)
                lstVolunteers.DataSource = xVol
                lstVolunteers.DisplayMember = "fullname"
                lstVolunteers.ValueMember = "VolunteerID"

            ElseIf Search = "Name" Then

                Dim xVol As List(Of VolunteerList) = VolunteerList.Search(txtName.Text, SearchParm.SearchByName)
                lstVolunteers.DataSource = xVol
                lstVolunteers.DisplayMember = "fullname"
                lstVolunteers.ValueMember = "VolunteerID"

            ElseIf Search = "Topic" Then

                Dim xVol As List(Of VolunteerList) = VolunteerList.Search(ddlTopics.Text, SearchParm.SearchByTopic)
                lstVolunteers.DataSource = xVol
                lstVolunteers.DisplayMember = "fullname"
                lstVolunteers.ValueMember = "VolunteerID"
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub


#End Region

    ''' <summary>
    ''' Handles the 1 event of the btnCreateBooking_Click control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub btnCreateBooking_Click_1(sender As System.Object, e As System.EventArgs) Handles btnRequestBooking.Click
        btnRequestBooking.Visible = False
        grpBooking.Visible = True
        btnCreate.Visible = True
        fillTopicdd(CInt(lstVolunteers.SelectedValue))
    End Sub

    ''' <summary>
    ''' Handles the Click event of the btnCreate control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub btnCreate_Click(sender As System.Object, e As System.EventArgs) Handles btnCreate.Click
        createBooking()
        grpBooking.Visible = False
        btnCreate.Visible = False
        btnRequestBooking.Visible = True
        getBookings(CInt(lstVolunteers.SelectedValue))
    End Sub

    ''' <summary>
    ''' Creates the booking.
    ''' </summary>
    Private Sub createBooking()
        Try
            Dim xBooking As Booking = New Booking()
            xBooking.volunteerID = CInt(lstVolunteers.SelectedValue)
            xBooking.teacherID = My.Settings.TeacherID
            xBooking.dateOfAppearance = dtp1.Value
            xBooking.TopicID = CInt(cmbTopicList.SelectedValue)
            BookingCUD.create(xBooking)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    ''' <summary>
    ''' Fills the topics list.
    ''' </summary>
    ''' <param name="volid">The volid.</param>
    Private Sub fillTopicsList(volid As Integer)
        Try
            Dim xTopic As List(Of Topic) = Topic.TopicLookup()
            cmbTopicList.DataSource = xTopic
            cmbTopicList.DisplayMember = "topicName"
            cmbTopicList.ValueMember = "topicID"
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    ''' <summary>
    ''' Fills the topicdd.
    ''' </summary>
    ''' <param name="volunteerID">The volunteer ID.</param>
    Private Sub fillTopicdd(volunteerID As Integer)
        Try
            Dim xTopic As List(Of Topic) = Topic.getVolunteerTopic(volunteerID)
            cmbTopicList.DataSource = xTopic
            cmbTopicList.DisplayMember = "topicName"
            cmbTopicList.ValueMember = "topicID"

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    ''' <summary>
    ''' Clears the form.
    ''' </summary>
    Private Sub clearForm()
        For Each ctl As Control In SplitContainer2.Panel1.Controls
            If TypeOf ctl Is GroupBox Then
                For Each ctlx As Control In ctl.Controls
                    If TypeOf ctlx Is TextBox OrElse
                        TypeOf ctlx Is ComboBox Then

                        ctlx.ResetText()

                    End If
                Next
            End If
        Next

        'lstVolunteers.DataSource = Nothing
        lstTopic.DataSource = Nothing
        dgvBookings.DataSource = Nothing

    End Sub


End Class