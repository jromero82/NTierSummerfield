﻿Option Strict On

Imports System.Data.SqlClient
Imports Summerfield.BOL
Imports Summerfield.Utilities

Public Class frmModifyVolunteer
    Private Search As String
    Private loading As Boolean

#Region "Form Load"

    ''' <summary>
    ''' Handles the Load event of the frmModifyVolunteer control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub frmModifyVolunteer_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        fillProvinces()
        fillVolunteerList()
        fillTopicDropDown()
        
    End Sub

    ''' <summary>
    ''' Fills the volunteer list.
    ''' </summary>
    Private Sub fillVolunteerList()
        loading = True
        Try
            Dim xVol As List(Of VolunteerList) = VolunteerList.VolunteerLookup()

            lstVolunteers.DataSource = xVol
            lstVolunteers.DisplayMember = "FullName"
            lstVolunteers.ValueMember = "VolunteerID"

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        loading = False

    End Sub

    ''' <summary>
    ''' Fills the topic list.
    ''' </summary>
    ''' <param name="volID">The vol ID.</param>
    Private Sub fillTopicList(volID As Integer)
        Try
            Dim xTopic As List(Of Topic) = Topic.getVolunteerTopic(volID)

            lstTopic.DataSource = xTopic
            lstTopic.DisplayMember = "topicName"
            lstTopic.ValueMember = "topicID"

        Catch ex As Exception
            lstTopic.DataSource = Nothing
            lstTopic.Items.Clear()
            MessageBox.Show(ex.Message)

        End Try

    End Sub

    ''' <summary>
    ''' Fills the provinces.
    ''' </summary>
    Private Sub fillProvinces()
        ddlProv.Items.Add("Alberta")
        ddlProv.Items.Add("British Columbia")
        ddlProv.Items.Add("Manitoba")
        ddlProv.Items.Add("New Brunswick")
        ddlProv.Items.Add("Newfoundland and Labrador")
        ddlProv.Items.Add("Northwest Territories")
        ddlProv.Items.Add("Nova Scotia")
        ddlProv.Items.Add("Nunavut")
        ddlProv.Items.Add("Ontario")
        ddlProv.Items.Add("Prince Edward Island")
        ddlProv.Items.Add("Quebec")
        ddlProv.Items.Add("Saskatchewan")
        ddlProv.Items.Add("Yukon")

    End Sub

    ''' <summary>
    ''' Fills the topic drop down.
    ''' </summary>
    Private Sub fillTopicDropDown()
        Try
            Dim xTopic As List(Of Topic) = Topic.TopicLookup()
            ddlTopics.DataSource = xTopic
            ddlTopics.DisplayMember = "topicName"
            ddlTopics.ValueMember = "topicID"
            cmbTopics.DataSource = xTopic
            cmbTopics.DisplayMember = "topicName"
            cmbTopics.ValueMember = "topicID"
            cmbTopics.Enabled = False
            btnAddTopic.Enabled = False
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

#End Region

#Region "Get Volunteer Details"

    ''' <summary>
    ''' Gets the volunteer details.
    ''' </summary>
    ''' <param name="VolID">The vol ID.</param>
    Private Sub getVolunteerDetails(VolID As Integer)
        Dim xVol As Volunteer
        xVol = Volunteer.Create(VolID)
        txtfName.Text = xVol.firstName
        txtlName.Text = xVol.lastName
        txtPhone.Text = xVol.phoneNumber
        txtEmail.Text = xVol.email
        txtStreet.Text = xVol.address
        txtCity.Text = xVol.city
        txtPostal.Text = xVol.postalCode
        ddlProv.SelectedItem = xVol.province
        txtAvail.Text = xVol.availability
        txtDesc.Text = xVol.notes
        getBookings(CInt(lstVolunteers.SelectedValue))
        fillTopicList(VolID)
    End Sub

    ''' <summary>
    ''' Gets the bookings.
    ''' </summary>
    ''' <param name="volID">The vol ID.</param>
    Public Sub getBookings(volID As Integer)
        If loading = False Then
            Try
                Dim xBooking As List(Of BookingLists) = BookingLists.getVolunteerBookings(volID)
                Dim BookingBindingSource As New BindingSource
                BookingBindingSource.DataSource = xBooking
                dgvBookings.DataSource = BookingBindingSource
                dgvBookings.Columns("VolunteerID").Visible = False
                dgvBookings.Columns("BookingID").Visible = False
                dgvBookings.Columns("TopicID").Visible = False
            Catch ex As Exception
                dgvBookings.DataSource = Nothing
                dgvBookings.Rows.Clear()

            End Try
        Else
            Exit Sub
        End If
        

    End Sub

    ''' <summary>
    ''' Handles the SelectedIndexChanged event of the lstVolunteers control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub lstVolunteers_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles lstVolunteers.Click
        If loading = False Then
            If Not lstVolunteers.SelectedIndex = -1 Then
                getVolunteerDetails(Convert.ToInt32(lstVolunteers.SelectedValue))

            End If
        Else
            Return
        End If
    End Sub




#End Region

#Region "Edit Volunteer"

    ''' <summary>
    ''' Handles the Click event of the btnEdit control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub btnEdit_Click(sender As System.Object, e As System.EventArgs) Handles btnEdit.Click
        EnableTextBoxes()
    End Sub

    ''' <summary>
    ''' Enables the text boxes.
    ''' </summary>
    Private Sub EnableTextBoxes()
        txtfName.Enabled = True
        txtlName.Enabled = True
        txtPhone.Enabled = True
        txtEmail.Enabled = True
        txtStreet.Enabled = True
        txtCity.Enabled = True
        ddlProv.Enabled = True
        txtPostal.Enabled = True
        txtDesc.Enabled = True
        txtAvail.Enabled = True
        btnEdit.Visible = False
        btnCancel.Visible = True
        cmbTopics.Enabled = True
        btnAddTopic.Enabled = True
        btnRemove.Enabled = True
    End Sub

    ''' <summary>
    ''' Handles the Click event of the btnCancel control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        btnEdit.Visible = True
        btnCancel.Visible = False
        txtfName.Enabled = False
        txtlName.Enabled = False
        txtPhone.Enabled = False
        txtEmail.Enabled = False
        txtStreet.Enabled = False
        txtCity.Enabled = False
        ddlProv.Enabled = False
        txtPostal.Enabled = False
        txtDesc.Enabled = False
        txtAvail.Enabled = False
    End Sub

    ''' <summary>
    ''' Handles the Click event of the btnAddTopic control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub btnAddTopic_Click(sender As System.Object, e As System.EventArgs) Handles btnAddTopic.Click
        Try
            Dim ok As Boolean = Volunteer.addVolunteerTopic(CInt(lstVolunteers.SelectedValue), CInt(cmbTopics.SelectedValue))
            If ok = True Then
                fillTopicList(CInt(lstVolunteers.SelectedValue))
            Else
                MessageBox.Show("Error adding topic to volunteer")
            End If
        Catch ex As SQLException
            MessageBox.Show(ex.Message)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    ''' <summary>
    ''' Handles the Click event of the btnRemove control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub btnRemove_Click(sender As System.Object, e As System.EventArgs) Handles btnRemove.Click
        Try
            Dim ok As Boolean = Volunteer.deleteVolunteerTopic(CInt(lstVolunteers.SelectedValue), CInt(cmbTopics.SelectedValue))
            If ok = True Then
                fillTopicList(CInt(lstVolunteers.SelectedValue))
            Else
                MessageBox.Show("Error adding topic to volunteer")
            End If
        Catch ex As SqlException
            MessageBox.Show(ex.Message)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub


#End Region

#Region "Save"

    ''' <summary>
    ''' Handles the Click event of the btnSave control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub btnSave_Click(sender As Object, e As System.EventArgs) Handles btnSave.Click
        SaveVolunteer()
        disableTextBoxes()
    End Sub

    ''' <summary>
    ''' Disables the text boxes.
    ''' </summary>
    Private Sub disableTextBoxes()
        txtfName.Enabled = False
        txtlName.Enabled = False
        txtPhone.Enabled = False
        txtEmail.Enabled = False
        txtStreet.Enabled = False
        txtCity.Enabled = False
        ddlProv.Enabled = False
        txtPostal.Enabled = False
        txtDesc.Enabled = False
        txtAvail.Enabled = False
        cmbTopics.Enabled = False
        btnAddTopic.Enabled = False
        btnRemove.Enabled = False
    End Sub

    ''' <summary>
    ''' Saves the volunteer.
    ''' </summary>
    Private Sub SaveVolunteer()
        Try
            Dim xVol As Volunteer = New Volunteer()
            xVol.VolunteerID = CInt(lstVolunteers.SelectedValue)
            xVol.firstName = txtfName.Text
            xVol.lastName = txtlName.Text
            xVol.phoneNumber = txtPhone.Text
            xVol.email = txtEmail.Text
            xVol.address = txtStreet.Text
            xVol.city = txtCity.Text
            xVol.province = ddlProv.SelectedItem.ToString()
            xVol.postalCode = txtPostal.Text
            xVol.availability = txtAvail.Text
            xVol.notes = txtDesc.Text
            Volunteer.EditVolunteer(xVol)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

#End Region

#Region "Search"

    ''' <summary>
    ''' Handles the Click event of the btnSearch control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub btnSearch_Click(sender As System.Object, e As System.EventArgs) Handles btnSearch.Click
        SearchVolunteers()
    End Sub

    ''' <summary>
    ''' Handles the CheckedChanged event of the rdo control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub rdo_CheckedChanged(sender As System.Object, e As System.EventArgs) _
        Handles rdoKeyword.CheckedChanged, rdoName.CheckedChanged, rdoTopic.CheckedChanged

        Select Case True
            Case rdoKeyword.Checked
                txtKeyword.Enabled = True
                txtName.Enabled = False
                ddlTopics.Enabled = False
                rdoName.Checked = False
                rdoTopic.Checked = False
                Search = "Keyword"
            Case rdoName.Checked
                txtKeyword.Enabled = False
                txtName.Enabled = True
                ddlTopics.Enabled = False
                rdoTopic.Checked = False
                Search = "Name"
            Case rdoTopic.Checked
                txtKeyword.Enabled = False
                txtName.Enabled = False
                ddlTopics.Enabled = True
                rdoName.Checked = False
                Search = "Topic"
        End Select

        clearForm()

        For Each ctl As Control In SplitContainer1.Panel1.Controls
            If TypeOf ctl Is GroupBox Then
                For Each ctlx As Control In ctl.Controls
                    If TypeOf ctlx Is TextBox OrElse
                        TypeOf ctlx Is ComboBox Then

                        ctlx.ResetText()

                    End If
                Next
            End If
        Next

    End Sub

    ''' <summary>
    ''' Searches the volunteers.
    ''' </summary>
    Private Sub SearchVolunteers()
        Try
            If Search = "Keyword" Then
                Dim xVol As List(Of VolunteerList) = VolunteerList.Search(txtKeyword.Text, SearchParm.SearchByKeyword)
                lstVolunteers.DataSource = xVol
                lstVolunteers.DisplayMember = "fullname"
                lstVolunteers.ValueMember = "VolunteerID"

            ElseIf Search = "Name" Then

                Dim xVol As List(Of VolunteerList) = VolunteerList.Search(txtName.Text, SearchParm.SearchByName)
                lstVolunteers.DataSource = xVol
                lstVolunteers.DisplayMember = "fullname"
                lstVolunteers.ValueMember = "VolunteerID"

            ElseIf Search = "Topic" Then

                Dim xVol As List(Of VolunteerList) = VolunteerList.Search(ddlTopics.Text, SearchParm.SearchByTopic)
                lstVolunteers.DataSource = xVol
                lstVolunteers.DisplayMember = "fullname"
                lstVolunteers.ValueMember = "VolunteerID"
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub


#End Region

    ''' <summary>
    ''' Handles the Click event of the btnDelete control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub btnDelete_Click(sender As System.Object, e As System.EventArgs) Handles btnDelete.Click
        Delete(CInt(lstVolunteers.SelectedValue))

    End Sub

    ''' <summary>
    ''' Clears the form.
    ''' </summary>
    Private Sub clearForm()
        For Each ctl As Control In SplitContainer2.Panel1.Controls
            If TypeOf ctl Is GroupBox Then
                For Each ctlx As Control In ctl.Controls
                    If TypeOf ctlx Is TextBox OrElse
                        TypeOf ctlx Is ComboBox Then

                        ctlx.ResetText()

                    End If
                Next
            End If
        Next

        lstVolunteers.DataSource = Nothing
        lstTopic.DataSource = Nothing
        dgvBookings.DataSource = Nothing

    End Sub

    ''' <summary>
    ''' Deletes the specified V ol ID.
    ''' </summary>
    ''' <param name="VOlID">The V ol ID.</param>
    Public Sub Delete(VOlID As Integer)
        Try
            Volunteer.delete(CInt(lstVolunteers.SelectedValue))
            fillProvinces()
            fillVolunteerList()
            fillTopicDropDown()
            getVolunteerDetails(CInt(lstVolunteers.SelectedValue))
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    
End Class