﻿Option Strict On

Imports Summerfield.BOL
Public Class MaintainTopics

    ''' <summary>
    ''' Handles the Load event of the MaintainTopics control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub MaintainTopics_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        LoadTopics()

    End Sub

    ''' <summary>
    ''' Loads the topics.
    ''' </summary>
    Private Sub LoadTopics()
        Try
            Dim xTopic As List(Of Topic) = Topic.TopicLookup()
            lstTopics.DataSource = xTopic
            lstTopics.DisplayMember = "topicName"
            lstTopics.ValueMember = "topicID"
        Catch ex As Exception
            lstTopics.DataSource = Nothing
            lstTopics.Items.Clear()
            MessageBox.Show(ex.Message)

        End Try
    End Sub

    ''' <summary>
    ''' Handles the Click event of the btnDelete control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub btnDelete_Click(sender As System.Object, e As System.EventArgs) Handles btnDelete.Click
        Try
            Topic.delete(CInt(lstTopics.SelectedValue))
            LoadTopics()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        
    End Sub

    ''' <summary>
    ''' Handles the Click event of the btnAddTopic control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub btnAddTopic_Click(sender As System.Object, e As System.EventArgs) Handles btnAddTopic.Click
        Try
            Dim strName As String = txtTopic.Text
            strName = StrConv(strName, VbStrConv.ProperCase)
            Topic.Addtopic(strName)
            LoadTopics()
            txtTopic.Text = ""
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        
    End Sub
End Class