﻿Imports Summerfield.BOL

Public Class browseBookings

    Private eRowIndex As Integer


    ''' <summary>
    ''' Handles the Click event of the btnSDate control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub btnSDate_Click(sender As System.Object, e As System.EventArgs) Handles btnSDate.Click

        If dtpMin.Value > dtpMax.Value Then
            lblMessage.Text = "Begin date must not be greater than end date"
        Else
            Try
        dgvBookings.Columns.Clear()

                Dim xBooking As List(Of BookingLists) = BookingLists.searchBookingsByDate(dtpMin.Value, dtpMax.Value)
                Dim BookingBindingSource As New BindingSource
                BookingBindingSource.DataSource = xBooking
                dgvBookings.DataSource = BookingBindingSource
                dgvBookings.Columns("VolunteerID").Visible = False
                dgvBookings.Columns("BookingID").Visible = False
                dgvBookings.Columns("TopicID").Visible = False
                Dim cbo As DataGridViewComboBoxColumn = New DataGridViewComboBoxColumn()
                cbo.HeaderText = "Status"
                dgvBookings.Columns.Add(cbo)

                cbo.Items.Add("Pending")
                cbo.Items.Add("Booked")
                cbo.Items.Add("Attended")
                cbo.Items.Add("Cancelled")

                cbo.DefaultCellStyle.NullValue = dgvBookings.Item("Status", eRowIndex).Value
                dgvBookings.Columns("Status").Visible = False
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
    End Sub

    ''' <summary>
    ''' Handles the Click event of the btnSVol control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub btnSVol_Click(sender As System.Object, e As System.EventArgs) Handles btnSVol.Click

        Try
            Dim xBooking As List(Of BookingLists) = BookingLists.searchBookingsByVolunteer(txtVolName.Text)
            If txtVolName.Text = String.Empty Then
                lblMessage.Text = "Please enter a volunteers name"
                Exit Sub
            End If
        dgvBookings.Columns.Clear()

            Dim BookingBindingSource As New BindingSource
            BookingBindingSource.DataSource = xBooking
            dgvBookings.DataSource = BookingBindingSource
            dgvBookings.Columns("VolunteerID").Visible = False
            dgvBookings.Columns("BookingID").Visible = False
            dgvBookings.Columns("TopicID").Visible = False
            Dim cbo As DataGridViewComboBoxColumn = New DataGridViewComboBoxColumn()
            cbo.HeaderText = "Status"
            dgvBookings.Columns.Add(cbo)
            cbo.Items.Add("Pending")
            cbo.Items.Add("Booked")
            cbo.Items.Add("Attended")
            cbo.Items.Add("Cancelled")

            cbo.DefaultCellStyle.NullValue = dgvBookings.Item("Status", eRowIndex).Value
            dgvBookings.Columns("Status").Visible = False
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    ''' <summary>
    ''' Handles the Click event of the btnSTeach control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub btnSTeach_Click(sender As System.Object, e As System.EventArgs) Handles btnSTeach.Click

        If txtTeachName.Text = String.Empty Then
            lblMessage.Text = "Please enter a teachers name"
            Exit Sub
        End If
        dgvBookings.Columns.Clear()
        Try
            dgvBookings.DataSource = Nothing
            Dim xBooking As List(Of BookingLists) = BookingLists.searchBookingsByTeacher(txtTeachName.Text)
            Dim BookingBindingSource As New BindingSource
            BookingBindingSource.DataSource = xBooking
            dgvBookings.DataSource = BookingBindingSource
            dgvBookings.Columns("VolunteerID").Visible = False
            dgvBookings.Columns("BookingID").Visible = False
            dgvBookings.Columns("TopicID").Visible = False
            Dim cbo As DataGridViewComboBoxColumn = New DataGridViewComboBoxColumn()
            cbo.HeaderText = "Status"
            dgvBookings.Columns.Add(cbo)
            cbo.Items.Add("Pending")
            cbo.Items.Add("Booked")
            cbo.Items.Add("Attended")
            cbo.Items.Add("Cancelled")

            cbo.DefaultCellStyle.NullValue = dgvBookings.Item("Status", eRowIndex).Value
            dgvBookings.Columns("Status").Visible = False
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    ''' <summary>
    ''' Handles the CellContentClick event of the dgvBookings control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.Windows.Forms.DataGridViewCellEventArgs" /> instance containing the event data.</param>
    Private Sub dgvBookings_CellContentClick(sender As System.Object, e As System.Windows.Forms.DataGridViewCellEventArgs)
        eRowIndex = e.RowIndex
    End Sub

    ''' <summary>
    ''' Handles the Click event of the btnSave control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub btnSave_Click(sender As System.Object, e As System.EventArgs) Handles btnSave.Click
        Dim xBook As Booking = New Booking()
        xBook.BookingID = dgvBookings.Item("BookingID", eRowIndex).Value
        xBook.volunteerID = dgvBookings.Item("VolunteerID", eRowIndex).Value
        xBook.teacherID = My.Settings.TeacherID
        xBook.DateOfBooking = dgvBookings.Item("creationDate", eRowIndex).Value
        xBook.dateOfAppearance = dgvBookings.Item("BookingDate", eRowIndex).Value
        xBook.status = dgvBookings.Item(9, eRowIndex).Value
        xBook.TopicID = dgvBookings.Item("TopicID", eRowIndex).Value
        Dim ok As Boolean = Booking.update(xBook)
        If ok = True Then
            lblMessage.Text = "Updated Successfully!"
        End If
    End Sub

    ''' <summary>
    ''' Handles the Click event of the txtTeachName control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub txtTeachName_Click(sender As Object, e As System.EventArgs) Handles txtTeachName.Click
        txtVolName.ResetText()
        dtpMin.Value = Date.Now
        dtpMax.Value = Date.Now
        dgvBookings.Columns.Clear()
    End Sub

    ''' <summary>
    ''' Handles the Click event of the txtVolName control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub txtVolName_Click(sender As Object, e As System.EventArgs) Handles txtVolName.Click
        txtTeachName.ResetText()
        dtpMin.Value = Date.Now
        dtpMax.Value = Date.Now
        dgvBookings.Columns.Clear()
    End Sub

    
    ''' <summary>
    ''' Handles the MouseDown event of the dtpMin control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.Windows.Forms.MouseEventArgs" /> instance containing the event data.</param>
    Private Sub dtpMin_MouseDown(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles dtpMin.MouseDown
        txtTeachName.ResetText()
        txtVolName.ResetText()
        dgvBookings.Columns.Clear()
    End Sub

    ''' <summary>
    ''' Handles the MouseDown event of the dtpMax control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.Windows.Forms.MouseEventArgs" /> instance containing the event data.</param>
    Private Sub dtpMax_MouseDown(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles dtpMax.MouseDown
        txtTeachName.ResetText()
        txtVolName.ResetText()
        dgvBookings.Columns.Clear()
    End Sub
End Class