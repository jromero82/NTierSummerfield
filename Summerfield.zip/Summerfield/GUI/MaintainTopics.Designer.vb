﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MaintainTopics
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstTopics = New System.Windows.Forms.ListBox()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.grpAdd = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtTopic = New System.Windows.Forms.TextBox()
        Me.btnAddTopic = New System.Windows.Forms.Button()
        Me.grpAdd.SuspendLayout()
        Me.SuspendLayout()
        '
        'lstTopics
        '
        Me.lstTopics.FormattingEnabled = True
        Me.lstTopics.Location = New System.Drawing.Point(287, 12)
        Me.lstTopics.Name = "lstTopics"
        Me.lstTopics.Size = New System.Drawing.Size(183, 160)
        Me.lstTopics.TabIndex = 0
        '
        'btnDelete
        '
        Me.btnDelete.Location = New System.Drawing.Point(334, 188)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(90, 23)
        Me.btnDelete.TabIndex = 1
        Me.btnDelete.Text = "Delete Topic"
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'grpAdd
        '
        Me.grpAdd.Controls.Add(Me.btnAddTopic)
        Me.grpAdd.Controls.Add(Me.txtTopic)
        Me.grpAdd.Controls.Add(Me.Label1)
        Me.grpAdd.Location = New System.Drawing.Point(12, 12)
        Me.grpAdd.Name = "grpAdd"
        Me.grpAdd.Size = New System.Drawing.Size(249, 103)
        Me.grpAdd.TabIndex = 2
        Me.grpAdd.TabStop = False
        Me.grpAdd.Text = "Add a Topic"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(7, 39)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Topic Name:"
        '
        'txtTopic
        '
        Me.txtTopic.Location = New System.Drawing.Point(81, 36)
        Me.txtTopic.Name = "txtTopic"
        Me.txtTopic.Size = New System.Drawing.Size(151, 20)
        Me.txtTopic.TabIndex = 1
        '
        'btnAddTopic
        '
        Me.btnAddTopic.Location = New System.Drawing.Point(81, 62)
        Me.btnAddTopic.Name = "btnAddTopic"
        Me.btnAddTopic.Size = New System.Drawing.Size(75, 23)
        Me.btnAddTopic.TabIndex = 2
        Me.btnAddTopic.Text = "Add Topic"
        Me.btnAddTopic.UseVisualStyleBackColor = True
        '
        'MaintainTopics
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(482, 246)
        Me.Controls.Add(Me.grpAdd)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.lstTopics)
        Me.Name = "MaintainTopics"
        Me.Text = "MaintainTopics"
        Me.grpAdd.ResumeLayout(False)
        Me.grpAdd.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lstTopics As System.Windows.Forms.ListBox
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents grpAdd As System.Windows.Forms.GroupBox
    Friend WithEvents btnAddTopic As System.Windows.Forms.Button
    Friend WithEvents txtTopic As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
