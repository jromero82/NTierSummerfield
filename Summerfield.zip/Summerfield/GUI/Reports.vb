﻿Imports Summerfield.BOL

Public Class Reports

    ''' <summary>
    ''' Handles the Load event of the Reports control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub Reports_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        fillDropDown()
    End Sub

    ''' <summary>
    ''' Fills the drop down.
    ''' </summary>
    Private Sub fillDropDown()
        cmbReports.Items.Add("All Teachers")
        cmbReports.Items.Add("All Topics")
        cmbReports.Items.Add("All Volunteers")
        cmbReports.Items.Add("All Volunteers active in past year")
        cmbReports.Items.Add("All Volunteers and their topics")
    End Sub

    ''' <summary>
    ''' Gets the type of the report.
    ''' </summary>
    Private Sub getReportType()
        Select Case True
            Case cmbReports.SelectedIndex = 0
                getAllTeachers()
            Case cmbReports.SelectedIndex = 1
                getAllTopics()
            Case cmbReports.SelectedIndex = 2
                getAllVolunteers()
            Case cmbReports.SelectedIndex = 3
                getAllActive()
            Case cmbReports.SelectedIndex = 4
                getAllVolunteerTopics()
        End Select
    End Sub

    ''' <summary>
    ''' Gets all teachers.
    ''' </summary>
    Private Sub getAllTeachers()
        lblReport.Text = "All Teachers"
        Try
            Dim xBooking As List(Of TeacherLists) = TeacherLists.reportAllTeachers()
            Dim BookingBindingSource As New BindingSource
            BookingBindingSource.DataSource = xBooking
            dgvResult.DataSource = BookingBindingSource
        Catch ex As Exception
            MessageBox.Show("Error retrieving teachers")
        End Try
    End Sub

    ''' <summary>
    ''' Gets all topics.
    ''' </summary>
    Private Sub getAllTopics()
        lblReport.Text = "All Topics"
        Try
            Dim xBooking As List(Of Topic) = Topic.TopicLookup()
            Dim BookingBindingSource As New BindingSource
            BookingBindingSource.DataSource = xBooking
            dgvResult.DataSource = BookingBindingSource
        Catch ex As Exception
            MessageBox.Show("Error retrieving topics")
        End Try

    End Sub

    ''' <summary>
    ''' Gets all volunteers.
    ''' </summary>
    Private Sub getAllVolunteers()
        lblReport.Text = "All Volunteers"
        Try
            Dim xBooking As List(Of VolunteerReport) = VolunteerReport.reportVolunteers()
            Dim BookingBindingSource As New BindingSource
            BookingBindingSource.DataSource = xBooking
            dgvResult.DataSource = BookingBindingSource
        Catch ex As Exception
            MessageBox.Show("Error retrieving Volunteers")
        End Try
    End Sub

    ''' <summary>
    ''' Gets all active.
    ''' </summary>
    Private Sub getAllActive()
        lblReport.Text = "All Volunteers who have fulfilled a booking in the past year"
        Try
            Dim xBooking As List(Of VolunteerReport) = VolunteerReport.reportActiveVolunteers()
            Dim BookingBindingSource As New BindingSource
            BookingBindingSource.DataSource = xBooking
            dgvResult.DataSource = BookingBindingSource
        Catch ex As Exception
            MessageBox.Show("Error retrieving Volunteers")
        End Try
    End Sub

    ''' <summary>
    ''' Gets all volunteer topics.
    ''' </summary>
    Private Sub getAllVolunteerTopics()
        lblReport.Text = "All Volunteers and the topics assigned to them"
        Try
            Dim xBooking As List(Of TopicReport) = TopicReport.getVolunteerTopics()
            Dim BookingBindingSource As New BindingSource
            BookingBindingSource.DataSource = xBooking
            dgvResult.DataSource = BookingBindingSource
        Catch ex As Exception
            MessageBox.Show("Error retrieving Volunteers")
        End Try
    End Sub

    ''' <summary>
    ''' Handles the SelectedIndexChanged event of the cmbReports control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub cmbReports_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles cmbReports.SelectedIndexChanged
        getReportType()
    End Sub

    ''' <summary>
    ''' Handles the Click event of the Button1 control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        MessageBox.Show("Printing " & lblReport.Text)
    End Sub
End Class