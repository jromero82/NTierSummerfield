﻿Option Strict On
Public Class main

#Region "Load"

    ''' <summary>
    ''' Handles the Load event of the main control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub main_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        If My.Settings.admin = False Then
            setupUserLinks()
        End If
        setUpStrip()

    End Sub

#End Region

#Region "Link Click"

    ''' <summary>
    ''' Links the click.
    ''' </summary>
    ''' <param name="sender">The sender.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub LinkClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblBBookings.Click, lblBVolunteers.Click, _
         lblMBooking.Click, lblMVolunteer.Click, lblMTeacher.Click, lblMTopic.Click, lblReports.Click

        Dim Formname As Form
        Dim linkclicked As Label = DirectCast(sender, Label)

        Select Case linkclicked.Text
            Case "Browse Bookings"
                Formname = browseBookings
                ToolStripStatusLabel3.Text = ("Browse Bookings")
            Case "Browse Volunteers"
                Formname = frmBrowseVolunteer
                ToolStripStatusLabel3.Text = ("Browse Volunteers")
            Case "Change a Booking"
                Formname = frmBrowseVolunteer
                ToolStripStatusLabel3.Text = ("Modify a Booking")
            Case "Volunteers"
                Formname = frmModifyVolunteer
                ToolStripStatusLabel3.Text = ("Add, Delete or Modify a Volunteer")
            Case "Teachers"
                Formname = frmMaintainTeachers
                ToolStripStatusLabel3.Text = ("Add, Delete or Modify a Teacher")
            Case "Topics"
                Formname = MaintainTopics
                ToolStripStatusLabel3.Text = ("Add, Delete or Modify a Topic")
            Case "Reports"
                Formname = Reports
                ToolStripStatusLabel3.Text = ("View or Print Reports")
            Case Else
                Exit Sub
        End Select
        If TabControl1.Contains(Formname) Then
            TabControl1.TabPages(Formname).Select()
        Else
            TabControl1.TabPages.Add(Formname)
        End If
    End Sub

#End Region

#Region "Status Strip"

    ''' <summary>
    ''' Sets up strip.
    ''' </summary>
    Public Sub setUpStrip()
        ToolStripStatusLabel1.Text = Date.Now.ToShortTimeString
        ToolStripStatusLabel2.Text = "Logged in as " & My.User.Name
        ToolStripStatusLabel3.Text = "Ready"
    End Sub

    ''' <summary>
    ''' Handles the tick event of the timer1 control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub timer1_tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        StatusStrip1.Items(0).Text = Date.Now.ToShortTimeString
    End Sub
#End Region

#Region "Menu Strip"

    ''' <summary>
    ''' Handles the Click event of the mmuAbout control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub mmuAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mmuAbout.Click
        AboutBox1.ShowDialog()
    End Sub

    ''' <summary>
    ''' Handles the click event of the mmuexit control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub mmuexit_click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
    End Sub

    ''' <summary>
    ''' Drops down item clicked.
    ''' </summary>
    ''' <param name="sender">The sender.</param>
    ''' <param name="e">The <see cref="System.Windows.Forms.ToolStripItemClickedEventArgs" /> instance containing the event data.</param>
    Private Sub DropDownItemClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) _
    Handles mmuNew.DropDownItemClicked, mmuAdmin.DropDownItemClicked, mmuReports.DropDownItemClicked, mmuHelp.DropDownItemClicked
        UpdateStatus(e.ClickedItem)
    End Sub

    ''' <summary>
    ''' Updates the status.
    ''' </summary>
    ''' <param name="item">The item.</param>
    Private Sub UpdateStatus(ByVal item As ToolStripItem)
        If item IsNot Nothing Then
            Dim msg As String = String.Format("{0} selected", item.Text)
            Me.StatusStrip1.Items(2).Text = msg
        End If
    End Sub
#End Region

#Region "Links"

    ''' <summary>
    ''' Lbllinks the specified sender.
    ''' </summary>
    ''' <param name="sender">The sender.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub lbllink(ByVal sender As Object, ByVal e As System.EventArgs) Handles lblBBookings.MouseEnter, lblBVolunteers.MouseEnter, _
        lblMBooking.MouseEnter, lblMVolunteer.MouseEnter, lblMTeacher.MouseEnter, lblMTopic.MouseEnter, lblReports.MouseEnter

        Dim linkselected As Label = DirectCast(sender, Label)
        Dim fontname As String = "candara"
        Dim fontsize As Integer = 12
        Dim FS As New Font(fontname, fontsize, FontStyle.Bold)
        linkselected.Font = FS
        linkselected.ForeColor = Color.Red

    End Sub

    ''' <summary>
    ''' Lblleaves the specified sender.
    ''' </summary>
    ''' <param name="sender">The sender.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Private Sub lblleave(ByVal sender As Object, ByVal e As System.EventArgs) Handles lblBBookings.MouseLeave, lblBVolunteers.MouseLeave, _
       lblMBooking.MouseLeave, lblMVolunteer.MouseLeave, lblMTeacher.MouseLeave, lblMTopic.MouseLeave, lblReports.MouseLeave

        Dim linkselected As Label = DirectCast(sender, Label)
        Dim fontname As String = "candara"
        Dim fontsize As Integer = 12
        Dim FS As New Font(fontname, fontsize, FontStyle.Italic)
        linkselected.Font = FS
        linkselected.ForeColor = Color.Black

    End Sub

    ''' <summary>
    ''' Setups the user links.
    ''' </summary>
    Private Sub setupUserLinks()
        lblMaintenance.Visible = False
        lblMBooking.Visible = False
        lblMVolunteer.Visible = False
        lblMTeacher.Visible = False
        lblMTopic.Visible = False
        lblReports.Visible = False
    End Sub

#End Region

#Region "Closing"

    ''' <summary>
    ''' Handles the FormClosing event of the Form1 control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.Windows.Forms.FormClosingEventArgs" /> instance containing the event data.</param>
    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        If StatusStrip1.Items.Count <> 0 Then
            StatusStrip1.Items(2).Text = ("Shutting Down")
            Application.DoEvents()
            'useProgressBar()
        End If


    End Sub

    ''' <summary>
    ''' Uses the progress bar.
    ''' </summary>
    Private Sub useProgressBar()
        Dim prgbar As ToolStripProgressBar = DirectCast(StatusStrip1.Items(1), ToolStripProgressBar)


        Do Until prgbar.Value = 100
            prgbar.Value = prgbar.Value + 5
            Threading.Thread.Sleep(300)
        Loop
    End Sub

#End Region

End Class