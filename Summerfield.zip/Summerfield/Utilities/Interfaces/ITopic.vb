﻿Option Strict On

Namespace Summerfield.Utilities

    Public Interface ITopic

        Property TopicID As Integer
        Property TopicName As String


    End Interface

End Namespace