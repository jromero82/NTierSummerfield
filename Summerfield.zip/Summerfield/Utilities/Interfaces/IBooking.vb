﻿Option Strict On

Namespace Summerfield.Utilities

    Public Interface IBooking

        Property bookingID As Integer
        Property teacherID As Integer
        Property volunteerID As Integer
        Property DateOfBooking As Date
        Property dateOfAppearance As Date
        Property status As String
        Property topicName As String
        Property topicID As Integer

    End Interface

End Namespace
