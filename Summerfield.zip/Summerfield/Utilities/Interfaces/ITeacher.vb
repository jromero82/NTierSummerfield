﻿Option Strict On

Namespace Summerfield.Utilities

    Public Interface ITeacher

        Property teacherID As Integer
        Property firstName As String
        Property lastName As String
        Property password As String
        Property email As String
        Property phoneNumber As String
        Property admin As Boolean

    End Interface

End Namespace
