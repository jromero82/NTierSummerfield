﻿Option Strict On

Namespace Summerfield.Utilities

    Public Interface IVolunteer

        Property VolunteerID As Integer
        Property FirstName As String
        Property LastName As String
        Property Address As String
        Property City As String
        Property Province As String
        Property PostalCode As String
        Property PhoneNumber As String
        Property Email As String
        Property Availability As String
        Property Notes As String
        Property Topic As String

    End Interface

End Namespace

