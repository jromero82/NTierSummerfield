﻿Option Strict On
Namespace Summerfield.Utilities

    Public Enum RetrieveType

        EntireFile = 1
        LookupTable = 2

    End Enum

    Public Structure Parm
        Public parmName As String
        Public parmValue As Object
        Public ParmDataType As System.Data.DbType
        Public ParmSize As Integer
        Public ParmDirection As System.Data.ParameterDirection

        ''' <summary>
        ''' Initializes a new instance of the <see cref="Parm" /> struct.
        ''' </summary>
        ''' <param name="name">The name.</param>
        ''' <param name="value">The value.</param>
        ''' <param name="direction">The direction.</param>
        ''' <param name="datatype">The datatype.</param>
        ''' <param name="size">The size.</param>
        Public Sub New(ByVal name As String, ByVal value As Object, _
                       ByVal direction As ParameterDirection, ByVal datatype As DbType, _
                       Optional ByVal size As Integer = 0)

            parmName = name
            parmValue = value
            ParmDataType = datatype
            ParmDirection = direction
            ParmSize = size

        End Sub

    End Structure

    Public Enum SearchParm
        SearchByKeyword = 1
        SearchByTopic = 2
        SearchByName = 3
    End Enum
End Namespace
