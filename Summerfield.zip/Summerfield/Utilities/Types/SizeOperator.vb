﻿Option Strict On
Namespace Summerfield.Utilities

    Public Enum SizeOperator
        MustBeEqualTo
        CanBeLessThan
    End Enum

    Public Enum CheckStringValue
        MustBeNumeric
        MustNotBeNullorEmpty
    End Enum

    Public Enum CheckNumericValue
        MustNotBeZero
        MustNotBeNegative
    End Enum

End Namespace
